using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Logging;
using Components;
using Components.RawComponents;
using Components.SharedContainerSingletons;
using Components.SingletonComponents;
using Components.Structs;
using HarmonyLib;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using Utility;
using Utility.EnumsStorage;
using Utility.NativeContainers;

namespace DinaoStorageAutoMarker
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public sealed class DinaoStorageAutoMarkerPlugin : BaseUnityPlugin
    {
        private const string PluginGuid = "local.codex.dinao.storage-auto-marker";
        private const string PluginName = "DINAO Helper";
        private const string HelperVersion = "A1.0 Stable";
        private const string PluginVersion = "1.0.0";
        private const int InstantDelayMs = 100;
        private const int TrainerWsiStorageHeadroom = 1000;
        private const float HostilePseudoPermanentSummonSeconds = 999999.0f;

        private static readonly MethodInfo GetComponentDataRawRwMethod =
            typeof(EntityManager).GetMethod("GetComponentDataRawRW", BindingFlags.Instance | BindingFlags.NonPublic);

        private delegate int StorageReader<T>(T storage) where T : struct, IComponentData;
        private delegate T StorageWriter<T>(T storage, int value) where T : struct, IComponentData;

        private struct DinaoCustomSummon : IComponentData
        {
            public float DurationSeconds;
        }

        private struct DinaoPendingPlayerizeSummon : IComponentData
        {
            public int UnitTypeId;
            public int Attempts;
        }

        private sealed class SummonMoveProbeState
        {
            public Entity Entity;
            public int UnitTypeId;
            public bool IsHostile;
            public float CreatedAtSeconds;
            public float LastSampleAtSeconds;
            public float CommandObservedAtSeconds;
            public int LastSignature;
            public int SampleCount;
            public int CommandStage;
        }

        private static readonly Dictionary<long, DateTime> ConstructionSeenUtc = new Dictionary<long, DateTime>();
        private static readonly Dictionary<long, DateTime> TrainingSeenUtc = new Dictionary<long, DateTime>();
        private static readonly Dictionary<long, SummonMoveProbeState> SummonMoveProbes =
            new Dictionary<long, SummonMoveProbeState>();
        private static readonly Dictionary<string, FieldInfo> FieldCache = new Dictionary<string, FieldInfo>();
        private static MethodInfo ManagedGetSingletonMethod;

        private static ManualLogSource Log;
        private static string StatePath;
        private static string ResourceCommandPath;
        private static string SummonCommandPath;
        private static string UnitCatalogPath;
        private static bool MissingSystemLogged;
        private static Entity TrainerWsiStorageEntity = Entity.Null;
        private static BlobAssetReference<StorageBaseData> TrainerWsiStorageBlob;
        private static int TrainerWsiStorageCapacity;
        private static object LastResourcesPanel;
        private static MethodInfo LastResourcesPanelUpdateValuesMethod;
        private static Type ResourcesPanelType;
        private static DateTime NextLogTimeUtc = DateTime.MinValue;
        private static DateTime NextStateReadUtc = DateTime.MinValue;
        private static DateTime NextResourceCommandReadUtc = DateTime.MinValue;
        private static DateTime NextSummonCommandReadUtc = DateTime.MinValue;
        private static DateTime NextWsiTotalsSyncUtc = DateTime.MinValue;
        private static DateTime NextHeartbeatUtc = DateTime.MinValue;
        private static DateTime NextConstructionLogUtc = DateTime.MinValue;
        private static DateTime NextTrainingLogUtc = DateTime.MinValue;
        private static DateTime NextUnitCatalogWriteUtc = DateTime.MinValue;
        private static DateTime NextResourcesPanelErrorLogUtc = DateTime.MinValue;
        private static DateTime NextResearchErrorLogUtc = DateTime.MinValue;
        private static DateTime LastResearchSeenUtc = DateTime.MinValue;
        private static int LastResearchId = -1;
        private static int LastSyncedWsiWood = int.MinValue;
        private static int LastSyncedWsiStone = int.MinValue;
        private static int LastSyncedWsiIron = int.MinValue;
        private static int LastSyncedWsiCapacity = int.MinValue;
        private static bool UnitCatalogWritten;
        private static TrainerState CurrentState = new TrainerState();
        private static SummonOverride CurrentSummonOverride = new SummonOverride();

        private void Awake()
        {
            Log = Logger;
            StatePath = Path.Combine(Paths.ConfigPath, "DinaoExternalTrainer.state.txt");
            ResourceCommandPath = Path.Combine(Paths.ConfigPath, "DinaoExternalTrainer.resource.txt");
            SummonCommandPath = Path.Combine(Paths.ConfigPath, "DinaoExternalTrainer.summon.txt");
            UnitCatalogPath = Path.Combine(Paths.ConfigPath, "DinaoExternalTrainer.units.txt");
            Logger.LogInfo("DINAO Helper " + HelperVersion + " / plugin " + PluginVersion +
                           " loaded. Effects are controlled by " + StatePath +
                           "; resource commands are read from " + ResourceCommandPath +
                           "; summon config is read from " + SummonCommandPath +
                           "; unit catalog is written to " + UnitCatalogPath + ".");

            Harmony harmony = new Harmony(PluginGuid);
            TryPatch("resource logger", delegate { PatchResourceLogger(harmony); });
            TryPatch("resources panel refresh", delegate { PatchResourcesPanel(harmony); });
            TryPatch("custom summon", delegate { PatchCustomSummon(harmony); });
            TryPatch("instant construction", delegate { PatchConstructionSystem(harmony); });
            TryPatch("instant research", delegate { PatchResearchSystem(harmony); });
            TryPatch("instant training", delegate { PatchArmyTrainingSystem(harmony); });
            TryPatch("helper tick", delegate { PatchGameStateUpdateHandler(harmony); });
        }

        private void OnDestroy()
        {
            DisposeTrainerWsiBlob();
        }

        private void Update()
        {
            RefreshStateIfDue();
            RefreshSummonOverrideIfDue();
            TryConsumeWsiResourceCommandFromActiveWorld();
            ApplyPendingPlayerizeSummonsFromActiveWorld();
            SampleSummonMoveProbesFromActiveWorld();
            ApplyCustomSummonLifetimeFromActiveWorld();
            WriteUnitCatalogIfDueFromActiveWorld();
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc >= NextHeartbeatUtc)
            {
                NextHeartbeatUtc = nowUtc.AddSeconds(10);
                LogInfo("Heartbeat: enabled=" + CurrentState.Enabled +
                        ", instantConstruction=" + CurrentState.InstantConstruction +
                        ", instantResearch=" + CurrentState.InstantResearch +
                        ", instantTraining=" + CurrentState.InstantTraining +
                        ", customSummon=" + CurrentSummonOverride.Enabled + ".");
            }
        }

        private static void TryPatch(string label, Action patch)
        {
            try
            {
                patch();
            }
            catch (Exception ex)
            {
                LogError("Failed to install " + label + " patch: " + ex);
            }
        }

        private static void PatchResourceLogger(Harmony harmony)
        {
            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "RunUpdateResourcePrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            MethodInfo postfix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "RunUpdateResourcePostfix",
                BindingFlags.NonPublic | BindingFlags.Static);

            int patched = 0;
            MethodInfo[] methods = typeof(ResourceUtility).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            for (int i = 0; i < methods.Length; i++)
            {
                MethodInfo method = methods[i];
                if (method.Name != "RunUpdateResource")
                {
                    continue;
                }

                harmony.Patch(method, prefix: new HarmonyMethod(prefix), postfix: new HarmonyMethod(postfix));
                patched++;
                LogInfo("Patched ResourceUtility.RunUpdateResource overload: " + method);
            }

            LogInfo("Resource address logger patches installed: " + patched);
        }

        private static void PatchConstructionSystem(Harmony harmony)
        {
            Type constructionType = AccessTools.TypeByName("Systems.ConstructionSystems.ConstructionSystem");
            if (constructionType == null)
            {
                LogError("ConstructionSystem type not found; instant construction is unavailable.");
                return;
            }

            MethodInfo method = AccessTools.Method(constructionType, "OnUpdateSimulation");
            if (method == null)
            {
                LogError("ConstructionSystem.OnUpdateSimulation not found; instant construction is unavailable.");
                return;
            }

            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "ConstructionSystemPrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, prefix: new HarmonyMethod(prefix));
            LogInfo("Instant construction patch installed: " + method);
        }

        private static void PatchResourcesPanel(Harmony harmony)
        {
            Type resourcesPanelType = AccessTools.TypeByName("UI.New.ResourcesPanel");
            if (resourcesPanelType == null)
            {
                LogError("UI.New.ResourcesPanel type not found; immediate resource UI refresh is unavailable.");
                return;
            }

            ResourcesPanelType = resourcesPanelType;
            MethodInfo postfix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "ResourcesPanelPostfix",
                BindingFlags.NonPublic | BindingFlags.Static);

            int patched = 0;
            string[] methodNames = new[] { "StartInit", "GameStateUpdateConsume", "UpdateValues" };
            for (int i = 0; i < methodNames.Length; i++)
            {
                MethodInfo method = AccessTools.Method(resourcesPanelType, methodNames[i]);
                if (method == null)
                {
                    continue;
                }

                harmony.Patch(method, postfix: new HarmonyMethod(postfix));
                patched++;
            }

            LastResourcesPanelUpdateValuesMethod = AccessTools.Method(resourcesPanelType, "UpdateValues");
            LogInfo("ResourcesPanel capture patches installed: " + patched + ".");
        }

        private static void PatchCustomSummon(Harmony harmony)
        {
            Type spellTargetType = AccessTools.TypeByName("Systems.SpellTargetSystem");
            if (spellTargetType == null)
            {
                LogError("SpellTargetSystem type not found; custom summon is unavailable.");
                return;
            }

            MethodInfo method = AccessTools.Method(spellTargetType, "summon_process_target_job_Execute");
            if (method == null)
            {
                LogError("SpellTargetSystem.summon_process_target_job_Execute not found; custom summon is unavailable.");
                return;
            }

            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "SummonProcessTargetPrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, prefix: new HarmonyMethod(prefix));
            LogInfo("Custom summon patch installed: " + method);
        }

        private static void PatchResearchSystem(Harmony harmony)
        {
            Type researchType = AccessTools.TypeByName("Systems.ResearchSystem");
            if (researchType == null)
            {
                LogError("ResearchSystem type not found; instant research is unavailable.");
                return;
            }

            MethodInfo method = AccessTools.Method(researchType, "OnUpdateSimulation");
            if (method == null)
            {
                LogError("ResearchSystem.OnUpdateSimulation not found; instant research is unavailable.");
                return;
            }

            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "ResearchSystemPrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, prefix: new HarmonyMethod(prefix));
            LogInfo("Instant research patch installed: " + method);
        }

        private static void PatchArmyTrainingSystem(Harmony harmony)
        {
            Type trainingType = AccessTools.TypeByName("Systems.ArmyTrainingSystem");
            if (trainingType == null)
            {
                LogError("ArmyTrainingSystem type not found; instant training is unavailable.");
                return;
            }

            MethodInfo method = AccessTools.Method(trainingType, "OnUpdateSimulation");
            if (method == null)
            {
                LogError("ArmyTrainingSystem.OnUpdateSimulation not found; instant training is unavailable.");
                return;
            }

            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "ArmyTrainingSystemPrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, prefix: new HarmonyMethod(prefix));
            LogInfo("Instant training patch installed: " + method);
        }

        private static void PatchGameStateUpdateHandler(Harmony harmony)
        {
            Type gameStateUpdateType = AccessTools.TypeByName("Systems.GameStateSystems.GameStateUpdateHandler");
            if (gameStateUpdateType == null)
            {
                LogError("GameStateUpdateHandler type not found; proactive helper tick is unavailable.");
                return;
            }

            MethodInfo method = AccessTools.Method(gameStateUpdateType, "OnUpdateSimulation");
            if (method == null)
            {
                LogError("GameStateUpdateHandler.OnUpdateSimulation not found; proactive helper tick is unavailable.");
                return;
            }

            MethodInfo prefix = typeof(DinaoStorageAutoMarkerPlugin).GetMethod(
                "GameStateUpdateHandlerPrefix",
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, prefix: new HarmonyMethod(prefix));
            LogInfo("Helper tick patch installed: " + method);
        }

        private static void RunUpdateResourcePrefix(object[] __args)
        {
            RefreshStateIfDue();

            SystemBase system = __args != null && __args.Length > 0 ? __args[0] as SystemBase : null;
            if (system == null)
            {
                if (!MissingSystemLogged)
                {
                    MissingSystemLogged = true;
                    LogInfo("RunUpdateResource prefix fired, but SystemBase argument is not available yet.");
                }

                return;
            }

            try
            {
                LogResourceAddressesIfDue(system.EntityManager, system.GetType().FullName);
            }
            catch (Exception ex)
            {
                LogError("Storage address logger failed: " + ex);
            }
        }

        private static void RunUpdateResourcePostfix(object[] __args)
        {
            RefreshStateIfDue();

            SystemBase system = __args != null && __args.Length > 0 ? __args[0] as SystemBase : null;
            if (system == null)
            {
                return;
            }

            try
            {
                TryConsumeWsiResourceCommand(system.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Resource postfix command processing failed: " + ex.Message);
            }
        }

        private static void ResourcesPanelPostfix(object __instance)
        {
            if (__instance != null)
            {
                LastResourcesPanel = __instance;
            }
        }

        private static void GameStateUpdateHandlerPrefix(object __instance)
        {
            SystemBase system = __instance as SystemBase;
            if (system == null)
            {
                return;
            }

            RunHelperTick(system);
        }

        private static void RunHelperTick(SystemBase system)
        {
            try
            {
                RefreshStateIfDue();
                RefreshSummonOverrideIfDue();
                TryConsumeWsiResourceCommand(system.EntityManager);
                SyncWsiTotalsFromStoragesIfDue(system.EntityManager);
                LogResourceAddressesIfDue(system.EntityManager, system.GetType().FullName);
                WriteUnitCatalogIfDue(system.EntityManager);
                ApplyPendingPlayerizeSummons(system.EntityManager);
                ApplyCustomSummonLifetime(system.EntityManager, Math.Max(0.0f, UnityEngine.Time.deltaTime));
                LogHeartbeatIfDue();
            }
            catch (Exception ex)
            {
                LogError("Helper tick failed: " + ex.Message);
            }
        }

        private static void LogHeartbeatIfDue()
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextHeartbeatUtc)
            {
                return;
            }

            NextHeartbeatUtc = nowUtc.AddSeconds(10);
            LogInfo("Heartbeat: enabled=" + CurrentState.Enabled +
                    ", instantConstruction=" + CurrentState.InstantConstruction +
                    ", instantResearch=" + CurrentState.InstantResearch +
                    ", instantTraining=" + CurrentState.InstantTraining +
                    ", customSummon=" + CurrentSummonOverride.Enabled + ".");
        }

        private static void LogResourceAddressesIfDue(EntityManager entityManager, string trigger)
        {
            if (!Systems.GameStateSystems.GameState.GameStarted)
            {
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextLogTimeUtc)
            {
                return;
            }

            NextLogTimeUtc = nowUtc.AddSeconds(2);

            LogInfo("Storage address logger triggered by " + trigger + ".");
            LogStorages<WoodStorage>(entityManager, "WoodStorage", GetWoodStored);
            LogStorages<StoneStorage>(entityManager, "StoneStorage", GetStoneStored);
            LogStorages<IronStorage>(entityManager, "IronStorage", GetIronStored);
            LogStorages<FoodStorage>(entityManager, "FoodStorage", GetFoodStored);

            LogCurrent<Components.RawComponents.CurrentWood>(entityManager, "CurrentWood");
            LogCurrent<Components.RawComponents.CurrentStone>(entityManager, "CurrentStone");
            LogCurrent<Components.RawComponents.CurrentIron>(entityManager, "CurrentIron");
            LogCurrent<Components.RawComponents.CurrentFood>(entityManager, "CurrentFood");
            LogCurrent<Components.RawComponents.CurrentSouls>(entityManager, "CurrentSouls");
            LogCurrent<Components.RawComponents.CurrentMoney>(entityManager, "CurrentMoney");
        }

        private static bool SummonProcessTargetPrefix(
            object __instance,
            EntityCommandBuffer changeBuffer,
            float3 groundPos,
            ref int remainingCount)
        {
            RefreshStateIfDue();
            RefreshSummonOverrideIfDue();

            if (!CurrentState.Enabled ||
                !CurrentSummonOverride.Enabled ||
                CurrentSummonOverride.Quantity <= 0 ||
                CurrentSummonOverride.UnitTypeIds.Count == 0)
            {
                return true;
            }

            SystemBase system = __instance as SystemBase;
            if (system == null)
            {
                LogError("Custom summon skipped: SpellTargetSystem instance is not a SystemBase.");
                return true;
            }

            try
            {
                int spawned = SpawnCustomSummons(system.EntityManager, changeBuffer, groundPos, CurrentSummonOverride);
                if (spawned > 0)
                {
                    remainingCount = 0;
                    LogInfo("Custom summon spawned " + spawned + " unit(s); skipped original summon job.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogError("Custom summon failed: " + ex.Message);
            }

            return true;
        }

        private static int SpawnCustomSummons(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            float3 groundPos,
            SummonOverride summon)
        {
            if (!Systems.GameStateSystems.GameState.PrefabsMap.IsCreated)
            {
                LogError("Custom summon skipped: GameState.PrefabsMap is not created.");
                return 0;
            }

            UnitSpawnUtility.MainThread spawner = UnitSpawnUtility.MainThread.Init(
                Systems.GameStateSystems.GameState.PrefabsMap,
                Systems.GameStateSystems.GameState.Settings);

            int spawned = 0;
            int convertedHostile = 0;
            int directHostilePrefab = 0;
            int totalPlanned = summon.UnitTypeIds.Count * Math.Max(0, summon.Quantity);
            for (int unitIndex = 0; unitIndex < summon.UnitTypeIds.Count; unitIndex++)
            {
                int unitTypeId = summon.UnitTypeIds[unitIndex];
                Entity prefab;
                if (!TryFindUnitPrefab(entityManager, unitTypeId, out prefab))
                {
                    LogError("Custom summon skipped unit type " + unitTypeId + ": prefab not found.");
                    continue;
                }

                Entity spawnPrefab = prefab;
                bool hostilePrefab = IsHostilePrefab(entityManager, prefab);

                for (int count = 0; count < summon.Quantity; count++)
                {
                    float3 position = GetSummonPosition(groundPos, spawned, totalPlanned);
                    Entity unit = spawner.Spawn(
                        spawnPrefab,
                        position,
                        quaternion.identity,
                        true,
                        true,
                        true,
                        changeBuffer,
                        entityManager);

                    bool timedSummon = summon.DurationSeconds > 0;
                    bool pseudoPermanentHostile = !timedSummon && hostilePrefab;
                    if (timedSummon || pseudoPermanentHostile)
                    {
                        float timerSeconds = timedSummon
                            ? (float)summon.DurationSeconds
                            : HostilePseudoPermanentSummonSeconds;
                        changeBuffer.AddComponent(unit, Summoned.SummonWithTimer(timerSeconds));

                        Progress progress = new Progress();
                        progress.Value = 1.0f;
                        changeBuffer.AddComponent(unit, progress);
                    }

                    if (timedSummon)
                    {
                        DinaoCustomSummon customSummon = new DinaoCustomSummon();
                        customSummon.DurationSeconds = Math.Max(1.0f, (float)summon.DurationSeconds);
                        changeBuffer.AddComponent(unit, customSummon);
                    }

                    if (pseudoPermanentHostile)
                    {
                        LogInfo("Custom summon hostile duration=0 uses pseudo permanent timer " +
                                HostilePseudoPermanentSummonSeconds.ToString("0", CultureInfo.InvariantCulture) +
                                "s for unitTypeId=" + unitTypeId + ".");
                    }

                    if (NormalizeSummonedUnitForPlayer(entityManager, changeBuffer, prefab, unit))
                    {
                        DinaoPendingPlayerizeSummon pending = new DinaoPendingPlayerizeSummon();
                        pending.UnitTypeId = unitTypeId;
                        pending.Attempts = 0;
                        changeBuffer.AddComponent(unit, pending);
                        convertedHostile++;
                        if (hostilePrefab)
                        {
                            directHostilePrefab++;
                        }
                    }

                    spawned++;
                }
            }

            if (convertedHostile > 0)
            {
                LogInfo("Custom summon converted " + convertedHostile +
                        " hostile prefab request(s) through player ownership handling; direct hostile prefabs=" +
                        directHostilePrefab + ".");
            }

            return spawned;
        }

        private static bool IsHostilePrefab(EntityManager entityManager, Entity prefab)
        {
            return entityManager.HasComponent<Enemy>(prefab) ||
                   entityManager.HasComponent<EnemyCitizen>(prefab) ||
                   entityManager.HasComponent<UndeadCitizen>(prefab) ||
                   entityManager.HasComponent(prefab, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));
        }

        private static bool TryFindPlayerTemplatePrefab(EntityManager entityManager, Entity desiredPrefab, out Entity templatePrefab)
        {
            if (entityManager.HasComponent<SiegeUnit>(desiredPrefab))
            {
                return TryFindFirstUnitPrefab(entityManager, out templatePrefab, 3, 6, 2, 42);
            }

            if (entityManager.HasComponent<CavalryUnit>(desiredPrefab))
            {
                return TryFindFirstUnitPrefab(entityManager, out templatePrefab, 8, 30, 2, 42);
            }

            if (entityManager.HasComponent<RangeUnit>(desiredPrefab))
            {
                return TryFindFirstUnitPrefab(entityManager, out templatePrefab, 41, 9, 1, 2);
            }

            return TryFindFirstUnitPrefab(entityManager, out templatePrefab, 42, 2, 10, 1);
        }

        private static bool TryFindFirstUnitPrefab(EntityManager entityManager, out Entity prefab, params int[] unitTypeIds)
        {
            for (int i = 0; i < unitTypeIds.Length; i++)
            {
                if (TryFindUnitPrefab(entityManager, unitTypeIds[i], out prefab) && !IsHostilePrefab(entityManager, prefab))
                {
                    return true;
                }
            }

            prefab = Entity.Null;
            return false;
        }

        private static bool NormalizeSummonedUnitForPlayer(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit)
        {
            bool hostile =
                entityManager.HasComponent<Enemy>(prefab) ||
                entityManager.HasComponent<EnemyCitizen>(prefab) ||
                entityManager.HasComponent<UndeadCitizen>(prefab) ||
                entityManager.HasComponent(prefab, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));

            bool removed = false;
            removed |= RemoveIfPrefabHas<Enemy>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<EnemyCitizen>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<EnemyLoiteringData>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<EnemyUnitMetadata>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<EnemyWallTag>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas(entityManager, changeBuffer, prefab, unit, typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy));
            removed |= RemoveIfPrefabHas<EnemyPatrolData>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<HideUnitInFog>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<UndeadCitizen>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<UndeadLoitering>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<UndeadArmyLimiter>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<UndeadDisabled>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<UndeadWatchTowerTag>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<EnemyCitizenInterestPoint>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.ArmyMoveLimiter>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.InAttackInMove>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.InAttackPoint>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.InForceAttack>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.InForceMove>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.RawComponents.InHold>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.SystemStateComponents.UnitCacheState>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.SystemStateComponents.NavObstacleCacheState>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.Skills.EnemyResurrector>(entityManager, changeBuffer, prefab, unit);
            removed |= RemoveIfPrefabHas<Components.Skills.EnemyResurrectionSkillData>(entityManager, changeBuffer, prefab, unit);
            if (hostile)
            {
                removed |= RemoveIfPrefabHas<Citizen>(entityManager, changeBuffer, prefab, unit);
                removed |= RemoveIfPrefabHas<Homeless>(entityManager, changeBuffer, prefab, unit);
                removed |= RemoveIfPrefabHas<Components.SystemStateComponents.ParentBuildingState>(entityManager, changeBuffer, prefab, unit);
            }

            if (hostile || removed)
            {
                AddPlayerControlComponentIfMissing<Unit>(entityManager, changeBuffer, prefab, unit);
                AddPlayerControlComponentIfMissing<Components.RawComponents.MoveHeading>(entityManager, changeBuffer, prefab, unit);
                AddManagedPlayerPathQueueIfMissing(entityManager, changeBuffer, prefab, unit);
                AddUnitCommandBufferIfMissing(entityManager, changeBuffer, prefab, unit);
                LogSummonControlSnapshot(entityManager, prefab, "spawn prefab");
            }

            return hostile || removed;
        }

        private static void AddPlayerControlComponentIfMissing<T>(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit)
            where T : struct, IComponentData
        {
            if (entityManager.HasComponent<T>(prefab))
            {
                return;
            }

            changeBuffer.AddComponent<T>(unit);
        }

        private static void AddManagedPlayerPathQueueIfMissing(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit)
        {
            ComponentType playerQueue = ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue));
            if (entityManager.HasComponent(prefab, playerQueue))
            {
                return;
            }

            changeBuffer.AddComponent(unit, playerQueue);
        }

        private static void AddUnitCommandBufferIfMissing(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit)
        {
            ComponentType unitCommand = ComponentType.ReadWrite(typeof(Components.RawComponents.FightComponents.UnitQueueCommand));
            if (!entityManager.HasComponent(prefab, unitCommand))
            {
                changeBuffer.AddBuffer<Components.RawComponents.FightComponents.UnitQueueCommand>(unit);
            }
        }

        private static void LogSummonControlSnapshot(EntityManager entityManager, Entity prefab, string stage)
        {
            try
            {
                bool hasPlayerQueue = entityManager.HasComponent(
                    prefab,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue)));
                bool hasEnemyQueue = entityManager.HasComponent(
                    prefab,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));
                bool unitCommandQueue = entityManager.HasComponent(
                    prefab,
                    ComponentType.ReadWrite(typeof(Components.RawComponents.FightComponents.UnitQueueCommand)));
                string unitType = "unknown";
                if (entityManager.HasComponent<UnitBase>(prefab))
                {
                    UnitBase unitBase = entityManager.GetComponentData<UnitBase>(prefab);
                    unitType = unitBase.GetData().type.ToString();
                }

                LogInfo("Summon control snapshot (" + stage + "): type=" + unitType +
                        ", Unit=" + entityManager.HasComponent<Unit>(prefab) +
                        ", Citizen=" + entityManager.HasComponent<Citizen>(prefab) +
                        ", Homeless=" + entityManager.HasComponent<Homeless>(prefab) +
                        ", ParentBuildingState=" + entityManager.HasComponent<Components.SystemStateComponents.ParentBuildingState>(prefab) +
                        ", Selectable=" + entityManager.HasComponent<Selectable>(prefab) +
                        ", UnitBase=" + entityManager.HasComponent<UnitBase>(prefab) +
                        ", UnitSizeBase=" + entityManager.HasComponent<UnitSizeBase>(prefab) +
                        ", MoveHeading=" + entityManager.HasComponent<Components.RawComponents.MoveHeading>(prefab) +
                        ", ObjectId=" + entityManager.HasComponent<Components.RawComponents.ObjectId>(prefab) +
                        ", Enemy=" + entityManager.HasComponent<Enemy>(prefab) +
                        ", EnemyCitizen=" + entityManager.HasComponent<EnemyCitizen>(prefab) +
                        ", playerPathQueue=" + hasPlayerQueue +
                        ", enemyPathQueue=" + hasEnemyQueue +
                        ", UnitQueueCommandBuffer=" + unitCommandQueue +
                        ", InAttackInMove=" + entityManager.HasComponent<Components.RawComponents.InAttackInMove>(prefab) +
                        ", InForceMove=" + entityManager.HasComponent<Components.RawComponents.InForceMove>(prefab) +
                        ", InForceAttack=" + entityManager.HasComponent<Components.RawComponents.InForceAttack>(prefab) +
                        ", InHold=" + entityManager.HasComponent<Components.RawComponents.InHold>(prefab) + ".");
            }
            catch (Exception ex)
            {
                LogError("Summon control snapshot failed: " + ex.Message);
            }
        }

        private static bool RemoveIfPrefabHas<T>(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit)
            where T : struct, IComponentData
        {
            if (!entityManager.HasComponent<T>(prefab))
            {
                return false;
            }

            changeBuffer.RemoveComponent<T>(unit);
            return true;
        }

        private static bool RemoveIfPrefabHas(
            EntityManager entityManager,
            EntityCommandBuffer changeBuffer,
            Entity prefab,
            Entity unit,
            Type componentType)
        {
            ComponentType type = ComponentType.ReadWrite(componentType);
            if (!entityManager.HasComponent(prefab, type))
            {
                return false;
            }

            changeBuffer.RemoveComponent(unit, type);
            return true;
        }

        private static float3 GetSummonPosition(float3 center, int index, int total)
        {
            if (total <= 1)
            {
                return center;
            }

            float angle = (float)(index * Math.PI * 2.0 / Math.Max(1, total));
            float radius = 1.25f + 0.1f * (index / 8);
            return new float3(
                center.x + math.cos(angle) * radius,
                center.y,
                center.z + math.sin(angle) * radius);
        }

        private static bool TryFindUnitPrefab(EntityManager entityManager, int unitTypeId, out Entity prefab)
        {
            prefab = Entity.Null;
            NativeArray<Entity> prefabs = Systems.GameStateSystems.GameState.PrefabsMap.GetValueArray(Allocator.Temp);
            try
            {
                for (int i = 0; i < prefabs.Length; i++)
                {
                    Entity candidate = prefabs[i];
                    if (!entityManager.Exists(candidate) || !entityManager.HasComponent<UnitBase>(candidate))
                    {
                        continue;
                    }

                    UnitBase unitBase = entityManager.GetComponentData<UnitBase>(candidate);
                    UnitBaseData data = unitBase.GetData();
                    if ((int)data.type == unitTypeId)
                    {
                        prefab = candidate;
                        return true;
                    }
                }
            }
            finally
            {
                prefabs.Dispose();
            }

            return false;
        }

        private static void WriteUnitCatalogIfDueFromActiveWorld()
        {
            try
            {
                World world = World.DefaultGameObjectInjectionWorld;
                if (world == null || !world.IsCreated)
                {
                    return;
                }

                WriteUnitCatalogIfDue(world.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Unit catalog write failed: " + ex.Message);
            }
        }

        private static void WriteUnitCatalogIfDue(EntityManager entityManager)
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextUnitCatalogWriteUtc)
            {
                return;
            }

            NextUnitCatalogWriteUtc = nowUtc.AddSeconds(UnitCatalogWritten ? 30 : 3);

            if (!Systems.GameStateSystems.GameState.PrefabsMap.IsCreated)
            {
                return;
            }

            TryWriteUnitCatalog(entityManager);
        }

        private static void TryWriteUnitCatalog(EntityManager entityManager)
        {
            if (string.IsNullOrEmpty(UnitCatalogPath))
            {
                return;
            }

            SortedDictionary<int, UnitCatalogEntry> entries = new SortedDictionary<int, UnitCatalogEntry>();
            NativeArray<Entity> prefabs = Systems.GameStateSystems.GameState.PrefabsMap.GetValueArray(Allocator.Temp);
            try
            {
                for (int i = 0; i < prefabs.Length; i++)
                {
                    Entity prefab = prefabs[i];
                    if (!entityManager.Exists(prefab) || !entityManager.HasComponent<UnitBase>(prefab))
                    {
                        continue;
                    }

                    UnitBase unitBase = entityManager.GetComponentData<UnitBase>(prefab);
                    int unitTypeId = (int)unitBase.GetData().type;
                    if (entries.ContainsKey(unitTypeId))
                    {
                        continue;
                    }

                    string englishName = Enum.GetName(typeof(UnitType), unitTypeId);
                    if (string.IsNullOrEmpty(englishName))
                    {
                        englishName = "UnitType" + unitTypeId;
                    }

                    string displayName = GetUnitDisplayName(entityManager, prefab, englishName);
                    entries[unitTypeId] = new UnitCatalogEntry(unitTypeId, englishName, displayName);
                }
            }
            finally
            {
                prefabs.Dispose();
            }

            if (entries.Count == 0)
            {
                return;
            }

            string directory = Path.GetDirectoryName(UnitCatalogPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine("# id|englishName|displayName");
            foreach (KeyValuePair<int, UnitCatalogEntry> pair in entries)
            {
                UnitCatalogEntry entry = pair.Value;
                builder.Append(entry.Id);
                builder.Append('|');
                builder.Append(EscapeCatalog(entry.EnglishName));
                builder.Append('|');
                builder.Append(EscapeCatalog(entry.DisplayName));
                builder.AppendLine();
            }

            string tempPath = UnitCatalogPath + ".tmp";
            File.WriteAllText(tempPath, builder.ToString(), Encoding.UTF8);
            if (File.Exists(UnitCatalogPath))
            {
                File.Delete(UnitCatalogPath);
            }

            File.Move(tempPath, UnitCatalogPath);
            if (!UnitCatalogWritten)
            {
                LogInfo("Wrote summon unit catalog entries=" + entries.Count + " to " + UnitCatalogPath + ".");
            }

            UnitCatalogWritten = true;
        }

        private static string GetUnitDisplayName(EntityManager entityManager, Entity prefab, string fallback)
        {
            if (!entityManager.HasComponent<ObjectId>(prefab))
            {
                return fallback;
            }

            ObjectId objectId = entityManager.GetComponentData<ObjectId>(prefab);
            ObjectUiData uiData;
            if (Systems.GameStateSystems.GameState.ObjectsUIDataMap == null ||
                !Systems.GameStateSystems.GameState.ObjectsUIDataMap.TryGetValue(objectId.value, out uiData))
            {
                return fallback;
            }

            string key = uiData.Name;
            string localized = TryLocalizeUnitName(key);
            if (!string.IsNullOrEmpty(localized))
            {
                return localized;
            }

            return fallback;
        }

        private static string TryLocalizeUnitName(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return null;
            }

            string localized = TryLocalization(delegate { return UI.LocalizationStrings.GetUnitsString(key); }, key);
            if (!string.IsNullOrEmpty(localized))
            {
                return localized;
            }

            localized = TryLocalization(delegate { return UI.LocalizationStrings.GetObjectString(key); }, key);
            return string.IsNullOrEmpty(localized) ? null : localized;
        }

        private static string TryLocalization(Func<string> localize, string key)
        {
            try
            {
                string localized = localize();
                if (string.IsNullOrEmpty(localized) ||
                    string.Equals(localized, key, StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                return localized;
            }
            catch
            {
                return null;
            }
        }

        private static string EscapeCatalog(string value)
        {
            return string.IsNullOrEmpty(value) ? string.Empty : value.Replace("|", "/").Replace("\r", " ").Replace("\n", " ");
        }

        private static void ApplyPendingPlayerizeSummonsFromActiveWorld()
        {
            try
            {
                World world = World.DefaultGameObjectInjectionWorld;
                if (world == null || !world.IsCreated || !Systems.GameStateSystems.GameState.GameStarted)
                {
                    return;
                }

                ApplyPendingPlayerizeSummons(world.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Pending summon playerize update failed: " + ex.Message);
            }
        }

        private static void ApplyPendingPlayerizeSummons(EntityManager entityManager)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(DinaoPendingPlayerizeSummon));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);

            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    if (!entityManager.Exists(entity))
                    {
                        continue;
                    }

                    DinaoPendingPlayerizeSummon pending =
                        entityManager.GetComponentData<DinaoPendingPlayerizeSummon>(entity);
                    bool copiedFog = PlayerizeSummonedEntity(entityManager, entity);
                    LogPlayerizedSummonSnapshot(entityManager, entity, pending.UnitTypeId, pending.Attempts, copiedFog);
                    RegisterMoveProbe(entity, pending.UnitTypeId, true, "post playerize");
                    LogRegisteredMoveBaseline(entityManager, entity, pending.UnitTypeId, true, "post playerize");

                    bool movementReady =
                        !entityManager.HasComponent<Enemy>(entity) &&
                        !entityManager.HasComponent<EnemyCitizen>(entity) &&
                        entityManager.HasComponent<Unit>(entity) &&
                        entityManager.HasComponent<Components.RawComponents.MoveHeading>(entity) &&
                        entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.RawComponents.FightComponents.UnitQueueCommand))) &&
                        entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue))) &&
                        !entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy))) &&
                        !entityManager.HasComponent<Citizen>(entity) &&
                        !entityManager.HasComponent<Homeless>(entity) &&
                        !entityManager.HasComponent<Components.SystemStateComponents.ParentBuildingState>(entity);

                    if (movementReady || pending.Attempts >= 10)
                    {
                        if (!movementReady)
                        {
                            LogPlayerizedSummonSnapshot(
                                entityManager,
                                entity,
                                pending.UnitTypeId,
                                pending.Attempts,
                                copiedFog,
                                "retry limit");
                        }

                        entityManager.RemoveComponent<DinaoPendingPlayerizeSummon>(entity);
                    }
                    else
                    {
                        pending.Attempts++;
                        entityManager.SetComponentData(entity, pending);
                    }
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static bool PlayerizeSummonedEntity(EntityManager entityManager, Entity entity)
        {
            RemoveEntityIfHas<Enemy>(entityManager, entity);
            RemoveEntityIfHas<EnemyCitizen>(entityManager, entity);
            RemoveEntityIfHas<EnemyLoiteringData>(entityManager, entity);
            RemoveEntityIfHas<EnemyUnitMetadata>(entityManager, entity);
            RemoveEntityIfHas<EnemyWallTag>(entityManager, entity);
            RemoveEntityIfHas(entityManager, entity, typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy));
            RemoveEntityIfHas<EnemyPatrolData>(entityManager, entity);
            RemoveEntityIfHas<HideUnitInFog>(entityManager, entity);
            RemoveEntityIfHas<UndeadCitizen>(entityManager, entity);
            RemoveEntityIfHas<UndeadLoitering>(entityManager, entity);
            RemoveEntityIfHas<UndeadArmyLimiter>(entityManager, entity);
            RemoveEntityIfHas<UndeadDisabled>(entityManager, entity);
            RemoveEntityIfHas<UndeadWatchTowerTag>(entityManager, entity);
            RemoveEntityIfHas<EnemyCitizenInterestPoint>(entityManager, entity);
            RemoveEntityIfHas<WaveHolderReference>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.ArmyMoveLimiter>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.InAttackInMove>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.InAttackPoint>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.InForceAttack>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.InForceMove>(entityManager, entity);
            RemoveEntityIfHas<Components.RawComponents.InHold>(entityManager, entity);
            RemoveEntityIfHas<Components.SystemStateComponents.UnitCacheState>(entityManager, entity);
            RemoveEntityIfHas<Components.SystemStateComponents.NavObstacleCacheState>(entityManager, entity);
            RemoveEntityIfHas<Components.Skills.EnemyResurrector>(entityManager, entity);
            RemoveEntityIfHas<Components.Skills.EnemyResurrectionSkillData>(entityManager, entity);
            RemoveEntityIfHas<Citizen>(entityManager, entity);
            RemoveEntityIfHas<Homeless>(entityManager, entity);
            RemoveEntityIfHas<Components.SystemStateComponents.ParentBuildingState>(entityManager, entity);

            AddEntityDataIfMissing(entityManager, entity, new Unit());
            AddEntityDataIfMissing(entityManager, entity, new Components.RawComponents.MoveHeading());
            AddEntityTypeIfMissing(entityManager, entity, typeof(Components.NativeContainerTrackers.PathRequestQueue));
            AddEntityBufferIfMissing<Components.RawComponents.FightComponents.UnitQueueCommand>(entityManager, entity);

            AddEntityDataIfMissing(entityManager, entity, new FogRevealerTag());
            return CopyPlayerFogData(entityManager, entity);
        }

        private static bool CopyPlayerFogData(EntityManager entityManager, Entity entity)
        {
            Entity template;
            if (!TryFindPlayerTemplatePrefab(entityManager, entity, out template) ||
                !entityManager.HasComponent<AffectFogBase>(template))
            {
                return entityManager.HasComponent<AffectFogBase>(entity);
            }

            AffectFogBase fog = entityManager.GetComponentData<AffectFogBase>(template);
            if (entityManager.HasComponent<AffectFogBase>(entity))
            {
                entityManager.SetComponentData(entity, fog);
            }
            else
            {
                entityManager.AddComponentData(entity, fog);
            }

            return true;
        }

        private static void LogPlayerizedSummonSnapshot(
            EntityManager entityManager,
            Entity entity,
            int unitTypeId,
            int attempt,
            bool copiedFog)
        {
            LogPlayerizedSummonSnapshot(entityManager, entity, unitTypeId, attempt, copiedFog, "post playerize");
        }

        private static void LogPlayerizedSummonSnapshot(
            EntityManager entityManager,
            Entity entity,
            int unitTypeId,
            int attempt,
            bool copiedFog,
            string stage)
        {
            try
            {
                bool playerQueue = entityManager.HasComponent(
                    entity,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue)));
                bool enemyQueue = entityManager.HasComponent(
                    entity,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));
                bool unitCommandQueue = entityManager.HasComponent(
                    entity,
                    ComponentType.ReadWrite(typeof(Components.RawComponents.FightComponents.UnitQueueCommand)));
                string unitType = "unknown";
                if (entityManager.HasComponent<UnitBase>(entity))
                {
                    UnitBase unitBase = entityManager.GetComponentData<UnitBase>(entity);
                    unitType = unitBase.GetData().type.ToString();
                }

                LogInfo("Playerized custom summon entity (" + stage + "): unitTypeId=" + unitTypeId +
                        ", type=" + unitType +
                        ", attempt=" + attempt +
                        ", Unit=" + entityManager.HasComponent<Unit>(entity) +
                        ", UnitBase=" + entityManager.HasComponent<UnitBase>(entity) +
                        ", UnitSizeBase=" + entityManager.HasComponent<UnitSizeBase>(entity) +
                        ", MoveHeading=" + entityManager.HasComponent<Components.RawComponents.MoveHeading>(entity) +
                        ", ObjectId=" + entityManager.HasComponent<Components.RawComponents.ObjectId>(entity) +
                        ", Selected=" + entityManager.HasComponent<Components.RawComponents.Selected>(entity) +
                        ", Translation=" + entityManager.HasComponent<Translation>(entity) +
                        ", Enemy=" + entityManager.HasComponent<Enemy>(entity) +
                        ", EnemyCitizen=" + entityManager.HasComponent<EnemyCitizen>(entity) +
                        ", playerPathQueue=" + playerQueue +
                        ", enemyPathQueue=" + enemyQueue +
                        ", UnitQueueCommandBuffer=" + unitCommandQueue +
                        ", AgentBase=" + entityManager.HasComponent<Components.Navigation.AgentBase>(entity) +
                        ", AgentStatus=" + entityManager.HasComponent<Components.Navigation.AgentStatus>(entity) +
                        ", AgentTarget=" + entityManager.HasComponent<Components.Navigation.AgentTarget>(entity) +
                        ", Citizen=" + entityManager.HasComponent<Citizen>(entity) +
                        ", Homeless=" + entityManager.HasComponent<Homeless>(entity) +
                        ", ParentBuildingState=" + entityManager.HasComponent<Components.SystemStateComponents.ParentBuildingState>(entity) +
                        ", InAttackInMove=" + entityManager.HasComponent<Components.RawComponents.InAttackInMove>(entity) +
                        ", InForceMove=" + entityManager.HasComponent<Components.RawComponents.InForceMove>(entity) +
                        ", InForceAttack=" + entityManager.HasComponent<Components.RawComponents.InForceAttack>(entity) +
                        ", InHold=" + entityManager.HasComponent<Components.RawComponents.InHold>(entity) +
                        ", FightTarget=" + entityManager.HasComponent<Components.RawComponents.FightTarget>(entity) +
                        ", ToInside=" + entityManager.HasComponent<Components.ToInside>(entity) +
                        ", FogRevealerTag=" + entityManager.HasComponent<FogRevealerTag>(entity) +
                        ", AffectFogBase=" + entityManager.HasComponent<AffectFogBase>(entity) +
                        ", copiedFog=" + copiedFog + ".");
            }
            catch (Exception ex)
            {
                LogError("Playerized summon entity snapshot failed: " + ex.Message);
            }
        }

        private static void SampleSummonMoveProbesFromActiveWorld()
        {
            try
            {
                World world = World.DefaultGameObjectInjectionWorld;
                if (world == null || !world.IsCreated || !Systems.GameStateSystems.GameState.GameStarted)
                {
                    return;
                }

                SampleSummonMoveProbes(world.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Summon move probe update failed: " + ex.Message);
            }
        }

        private static void SampleSummonMoveProbes(EntityManager entityManager)
        {
            AttachMissingMoveProbesFromCustomSummons(entityManager);

            float nowSeconds = UnityEngine.Time.realtimeSinceStartup;
            List<long> keys = new List<long>(SummonMoveProbes.Keys);

            for (int i = 0; i < keys.Count; i++)
            {
                long key = keys[i];
                SummonMoveProbeState probe;
                if (!SummonMoveProbes.TryGetValue(key, out probe))
                {
                    continue;
                }

                Entity entity = probe.Entity;
                if (!entityManager.Exists(entity))
                {
                    if (nowSeconds - probe.CreatedAtSeconds > 5.0f)
                    {
                        SummonMoveProbes.Remove(key);
                    }

                    continue;
                }

                float ageSeconds = nowSeconds - probe.CreatedAtSeconds;
                bool selected = entityManager.HasComponent<Components.RawComponents.Selected>(entity);
                if ((ageSeconds > 180.0f && !selected) || entityManager.HasComponent<Dead>(entity))
                {
                    SummonMoveProbes.Remove(key);
                    continue;
                }

                int signature = ComputeMoveProbeSignature(entityManager, entity);
                bool baseline = probe.SampleCount == 0;
                bool signatureChanged = probe.LastSignature != int.MinValue && signature != probe.LastSignature;
                bool selectedPeriodic = selected && nowSeconds - probe.LastSampleAtSeconds >= 0.25f;

                if (baseline)
                {
                    LogMoveProbeSnapshot(entityManager, entity, probe, "baseline");
                    probe.LastSampleAtSeconds = nowSeconds;
                    probe.SampleCount++;
                }

                if (selected && signatureChanged && probe.CommandObservedAtSeconds < 0.0f)
                {
                    probe.CommandObservedAtSeconds = nowSeconds;
                    probe.CommandStage = 0;
                    LogMoveProbeSnapshot(entityManager, entity, probe, "command observed");
                    probe.LastSampleAtSeconds = nowSeconds;
                    probe.SampleCount++;
                }
                else if (selected && signatureChanged && nowSeconds - probe.LastSampleAtSeconds >= 0.05f)
                {
                    LogMoveProbeSnapshot(entityManager, entity, probe, "movement signature changed");
                    probe.LastSampleAtSeconds = nowSeconds;
                    probe.SampleCount++;
                }

                if (probe.CommandObservedAtSeconds >= 0.0f)
                {
                    float commandAge = nowSeconds - probe.CommandObservedAtSeconds;
                    if (probe.CommandStage == 0 && commandAge > 0.02f)
                    {
                        probe.CommandStage = 1;
                        LogMoveProbeSnapshot(entityManager, entity, probe, "command next frame");
                        probe.LastSampleAtSeconds = nowSeconds;
                        probe.SampleCount++;
                    }
                    else if (probe.CommandStage == 1 && commandAge >= 0.30f)
                    {
                        probe.CommandStage = 2;
                        LogMoveProbeSnapshot(entityManager, entity, probe, "command +300ms");
                        probe.LastSampleAtSeconds = nowSeconds;
                        probe.SampleCount++;
                    }
                }
                else if (selectedPeriodic)
                {
                    LogMoveProbeSnapshot(entityManager, entity, probe, "selected periodic");
                    probe.LastSampleAtSeconds = nowSeconds;
                    probe.SampleCount++;
                }

                probe.LastSignature = signature;
            }
        }

        private static void AttachMissingMoveProbesFromCustomSummons(EntityManager entityManager)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(DinaoCustomSummon), typeof(UnitBase));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);

            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    if (!entityManager.Exists(entity) ||
                        entityManager.HasComponent<Dead>(entity) ||
                        SummonMoveProbes.ContainsKey(GetEntityKey(entity)))
                    {
                        continue;
                    }

                    int unitTypeId;
                    if (!TryReadUnitTypeId(entityManager, entity, out unitTypeId))
                    {
                        unitTypeId = -1;
                    }

                    RegisterMoveProbe(entity, unitTypeId, IsHostileLiveEntity(entityManager, entity), "custom summon scan");
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void RegisterMoveProbe(
            Entity entity,
            int unitTypeId,
            bool isHostile,
            string reason)
        {
            long key = GetEntityKey(entity);
            SummonMoveProbeState probe;
            if (!SummonMoveProbes.TryGetValue(key, out probe))
            {
                probe = new SummonMoveProbeState();
                probe.Entity = entity;
                probe.UnitTypeId = unitTypeId;
                probe.IsHostile = isHostile;
                probe.CreatedAtSeconds = UnityEngine.Time.realtimeSinceStartup;
                probe.LastSampleAtSeconds = -999.0f;
                probe.CommandObservedAtSeconds = -1.0f;
                probe.LastSignature = int.MinValue;
                probe.SampleCount = 0;
                probe.CommandStage = -1;
                SummonMoveProbes[key] = probe;
                LogInfo("Registered summon move probe: reason=" + reason +
                        ", side=" + (isHostile ? "hostile" : "player") +
                        ", unitTypeId=" + unitTypeId +
                        ", entity=" + FormatEntity(entity) + ".");
                return;
            }

            if (probe.UnitTypeId <= 0 && unitTypeId > 0)
            {
                probe.UnitTypeId = unitTypeId;
            }

            if (isHostile)
            {
                probe.IsHostile = true;
            }
        }

        private static void LogRegisteredMoveBaseline(
            EntityManager entityManager,
            Entity entity,
            int unitTypeId,
            bool isHostile,
            string reason)
        {
            try
            {
                if (!entityManager.Exists(entity))
                {
                    return;
                }

                SummonMoveProbeState probe = new SummonMoveProbeState();
                probe.Entity = entity;
                probe.UnitTypeId = unitTypeId;
                probe.IsHostile = isHostile;
                probe.CreatedAtSeconds = UnityEngine.Time.realtimeSinceStartup;
                probe.LastSampleAtSeconds = -999.0f;
                probe.CommandObservedAtSeconds = -1.0f;
                probe.LastSignature = int.MinValue;
                probe.SampleCount = 0;
                probe.CommandStage = -1;
                LogMoveProbeSnapshot(entityManager, entity, probe, "registered baseline " + reason);
            }
            catch (Exception ex)
            {
                LogError("Registered summon move baseline failed: " + ex.Message);
            }
        }

        private static long GetEntityKey(Entity entity)
        {
            return ((long)entity.Version << 32) ^ (uint)entity.Index;
        }

        private static bool TryReadUnitTypeId(EntityManager entityManager, Entity entity, out int unitTypeId)
        {
            unitTypeId = -1;
            if (!entityManager.Exists(entity) || !entityManager.HasComponent<UnitBase>(entity))
            {
                return false;
            }

            UnitBase unitBase = entityManager.GetComponentData<UnitBase>(entity);
            unitTypeId = (int)unitBase.GetData().type;
            return true;
        }

        private static bool IsHostileLiveEntity(EntityManager entityManager, Entity entity)
        {
            return entityManager.HasComponent<Enemy>(entity) ||
                   entityManager.HasComponent<EnemyCitizen>(entity) ||
                   entityManager.HasComponent<UndeadCitizen>(entity) ||
                   entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));
        }

        private static int ComputeMoveProbeSignature(EntityManager entityManager, Entity entity)
        {
            unchecked
            {
                int hash = 17;
                AppendHash(ref hash, entityManager.HasComponent<Unit>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Enemy>(entity));
                AppendHash(ref hash, entityManager.HasComponent<EnemyCitizen>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Citizen>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Homeless>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.SystemStateComponents.ParentBuildingState>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.MoveHeading>(entity));
                AppendHash(ref hash, entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue))));
                AppendHash(ref hash, entityManager.HasComponent(entity, ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy))));
                AppendHash(ref hash, GetBufferLength<Components.RawComponents.FightComponents.UnitQueueCommand>(entityManager, entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.Navigation.AgentTarget>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.InAttackInMove>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.InForceMove>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.InForceAttack>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.InAttackPoint>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.FightTarget>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.ToInside>(entity));
                AppendHash(ref hash, entityManager.HasComponent<Components.RawComponents.UnitToTower>(entity));
                AppendHash(ref hash, DumpComponentData<Translation>(entityManager, entity));
                AppendHash(ref hash, DumpComponentData<Components.Navigation.AgentTarget>(entityManager, entity));
                AppendHash(ref hash, DumpComponentData<Components.Navigation.AgentStatus>(entityManager, entity));
                AppendHash(ref hash, DumpComponentData<Components.RawComponents.MoveHeading>(entityManager, entity));
                AppendHash(ref hash, DumpComponentData<Components.RawComponents.FightTarget>(entityManager, entity));
                AppendHash(ref hash, DumpComponentData<Components.ToInside>(entityManager, entity));
                return hash;
            }
        }

        private static void LogMoveProbeSnapshot(
            EntityManager entityManager,
            Entity entity,
            SummonMoveProbeState probe,
            string stage)
        {
            try
            {
                bool playerQueue = entityManager.HasComponent(
                    entity,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueue)));
                bool enemyQueue = entityManager.HasComponent(
                    entity,
                    ComponentType.ReadWrite(typeof(Components.NativeContainerTrackers.PathRequestQueueEnemy)));
                int commandLength = GetBufferLength<Components.RawComponents.FightComponents.UnitQueueCommand>(entityManager, entity);
                string typeText = "unknown";
                if (entityManager.HasComponent<UnitBase>(entity))
                {
                    UnitBase unitBase = entityManager.GetComponentData<UnitBase>(entity);
                    typeText = unitBase.GetData().type.ToString();
                }

                float ageSeconds = UnityEngine.Time.realtimeSinceStartup - probe.CreatedAtSeconds;
                LogInfo("Summon move probe (" + stage + "): side=" + (probe.IsHostile ? "hostile" : "player") +
                        ", entity=" + FormatEntity(entity) +
                        ", unitTypeId=" + probe.UnitTypeId +
                        ", type=" + typeText +
                        ", age=" + ageSeconds.ToString("0.000", CultureInfo.InvariantCulture) +
                        ", selected=" + entityManager.HasComponent<Components.RawComponents.Selected>(entity) +
                        ", Unit=" + entityManager.HasComponent<Unit>(entity) +
                        ", Enemy=" + entityManager.HasComponent<Enemy>(entity) +
                        ", EnemyCitizen=" + entityManager.HasComponent<EnemyCitizen>(entity) +
                        ", Citizen=" + entityManager.HasComponent<Citizen>(entity) +
                        ", Homeless=" + entityManager.HasComponent<Homeless>(entity) +
                        ", ParentBuildingState=" + entityManager.HasComponent<Components.SystemStateComponents.ParentBuildingState>(entity) +
                        ", UnitQueueCommandLength=" + commandLength +
                        ", playerPathQueue=" + playerQueue +
                        ", enemyPathQueue=" + enemyQueue +
                        ", AgentBase=" + DumpComponentData<Components.Navigation.AgentBase>(entityManager, entity) +
                        ", AgentStatus=" + DumpComponentData<Components.Navigation.AgentStatus>(entityManager, entity) +
                        ", AgentTarget=" + DumpComponentData<Components.Navigation.AgentTarget>(entityManager, entity) +
                        ", Translation=" + DumpComponentData<Translation>(entityManager, entity) +
                        ", MoveHeading=" + DumpComponentData<Components.RawComponents.MoveHeading>(entityManager, entity) +
                        ", InAttackInMove=" + DumpComponentData<Components.RawComponents.InAttackInMove>(entityManager, entity) +
                        ", InForceMove=" + DumpComponentData<Components.RawComponents.InForceMove>(entityManager, entity) +
                        ", InForceAttack=" + DumpComponentData<Components.RawComponents.InForceAttack>(entityManager, entity) +
                        ", InAttackPoint=" + DumpComponentData<Components.RawComponents.InAttackPoint>(entityManager, entity) +
                        ", FightTarget=" + DumpComponentData<Components.RawComponents.FightTarget>(entityManager, entity) +
                        ", ToInside=" + DumpComponentData<Components.ToInside>(entityManager, entity) +
                        ", UnitToTower=" + DumpComponentData<Components.RawComponents.UnitToTower>(entityManager, entity) +
                        ", PickupTarget=" + DumpComponentData<Components.PickupTarget>(entityManager, entity) +
                        ", FogRevealerTag=" + entityManager.HasComponent<FogRevealerTag>(entity) +
                        ", AffectFogBase=" + DumpComponentData<AffectFogBase>(entityManager, entity) + ".");
            }
            catch (Exception ex)
            {
                LogError("Summon move probe snapshot failed: " + ex.Message);
            }
        }

        private static void AppendHash(ref int hash, bool value)
        {
            unchecked
            {
                hash = hash * 31 + (value ? 1 : 0);
            }
        }

        private static void AppendHash(ref int hash, int value)
        {
            unchecked
            {
                hash = hash * 31 + value;
            }
        }

        private static void AppendHash(ref int hash, string value)
        {
            unchecked
            {
                hash = hash * 31 + (value == null ? 0 : value.GetHashCode());
            }
        }

        private static int GetBufferLength<T>(EntityManager entityManager, Entity entity)
            where T : struct, IBufferElementData
        {
            if (!entityManager.HasComponent<T>(entity))
            {
                return -1;
            }

            try
            {
                return entityManager.GetBuffer<T>(entity).Length;
            }
            catch
            {
                return -2;
            }
        }

        private static string DumpComponentData<T>(EntityManager entityManager, Entity entity)
            where T : struct, IComponentData
        {
            if (!entityManager.HasComponent<T>(entity))
            {
                return "<none>";
            }

            try
            {
                T data = entityManager.GetComponentData<T>(entity);
                return FormatStructData(data);
            }
            catch (Exception ex)
            {
                return "<read failed:" + ex.GetType().Name + ">";
            }
        }

        private static string FormatStructData<T>(T data)
            where T : struct
        {
            object boxed = data;
            Type type = boxed.GetType();
            FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (fields.Length == 0)
            {
                return boxed.ToString();
            }

            StringBuilder builder = new StringBuilder();
            int count = Math.Min(fields.Length, 8);
            for (int i = 0; i < count; i++)
            {
                if (i > 0)
                {
                    builder.Append(",");
                }

                FieldInfo field = fields[i];
                builder.Append(field.Name);
                builder.Append("=");
                object value = field.GetValue(boxed);
                builder.Append(FormatComponentValue(value));
            }

            if (fields.Length > count)
            {
                builder.Append(",...");
            }

            return builder.ToString();
        }

        private static string FormatComponentValue(object value)
        {
            if (value == null)
            {
                return "null";
            }

            if (value is float)
            {
                return ((float)value).ToString("0.###", CultureInfo.InvariantCulture);
            }

            if (value is double)
            {
                return ((double)value).ToString("0.###", CultureInfo.InvariantCulture);
            }

            if (value is Entity)
            {
                return FormatEntity((Entity)value);
            }

            string text = value.ToString();
            if (text.Length > 80)
            {
                return text.Substring(0, 80);
            }

            return text;
        }

        private static void AddEntityDataIfMissing<T>(EntityManager entityManager, Entity entity, T data)
            where T : struct, IComponentData
        {
            if (!entityManager.HasComponent<T>(entity))
            {
                entityManager.AddComponentData(entity, data);
            }
        }

        private static void AddEntityTypeIfMissing(EntityManager entityManager, Entity entity, Type componentType)
        {
            ComponentType type = ComponentType.ReadWrite(componentType);
            if (!entityManager.HasComponent(entity, type))
            {
                entityManager.AddComponent(entity, type);
            }
        }

        private static void AddEntityBufferIfMissing<T>(EntityManager entityManager, Entity entity)
            where T : struct, IBufferElementData
        {
            if (!entityManager.HasComponent<T>(entity))
            {
                entityManager.AddBuffer<T>(entity);
            }
        }

        private static bool RemoveEntityIfHas<T>(EntityManager entityManager, Entity entity)
            where T : struct, IComponentData
        {
            if (!entityManager.HasComponent<T>(entity))
            {
                return false;
            }

            entityManager.RemoveComponent<T>(entity);
            return true;
        }

        private static bool RemoveEntityIfHas(EntityManager entityManager, Entity entity, Type componentType)
        {
            ComponentType type = ComponentType.ReadWrite(componentType);
            if (!entityManager.HasComponent(entity, type))
            {
                return false;
            }

            entityManager.RemoveComponent(entity, type);
            return true;
        }

        private static void ApplyCustomSummonLifetimeFromActiveWorld()
        {
            try
            {
                World world = World.DefaultGameObjectInjectionWorld;
                if (world == null || !world.IsCreated || !Systems.GameStateSystems.GameState.GameStarted)
                {
                    return;
                }

                ApplyCustomSummonLifetime(world.EntityManager, Math.Max(0.0f, UnityEngine.Time.deltaTime));
            }
            catch (Exception ex)
            {
                LogError("Custom summon lifetime update failed: " + ex.Message);
            }
        }

        private static void ApplyCustomSummonLifetime(EntityManager entityManager, float deltaTime)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(DinaoCustomSummon), typeof(Summoned));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);

            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    if (!entityManager.Exists(entity) || entityManager.HasComponent<Dead>(entity))
                    {
                        continue;
                    }

                    DinaoCustomSummon custom = entityManager.GetComponentData<DinaoCustomSummon>(entity);
                    Summoned summoned = entityManager.GetComponentData<Summoned>(entity);
                    if (summoned.IsPersistent)
                    {
                        continue;
                    }

                    summoned.timeToDisappear -= deltaTime;
                    if (summoned.timeToDisappear <= 0.0f)
                    {
                        entityManager.SetComponentData(entity, summoned);
                        entityManager.AddComponentData(entity, new Dead(0.0f, false));
                        continue;
                    }

                    entityManager.SetComponentData(entity, summoned);
                    if (entityManager.HasComponent<Progress>(entity))
                    {
                        Progress progress = entityManager.GetComponentData<Progress>(entity);
                        progress.Value = Math.Max(0.0f, Math.Min(1.0f, summoned.timeToDisappear / Math.Max(1.0f, custom.DurationSeconds)));
                        entityManager.SetComponentData(entity, progress);
                    }
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private struct UnitCatalogEntry
        {
            public readonly int Id;
            public readonly string EnglishName;
            public readonly string DisplayName;

            public UnitCatalogEntry(int id, string englishName, string displayName)
            {
                Id = id;
                EnglishName = englishName;
                DisplayName = displayName;
            }
        }

        private static void TryConsumeWsiResourceCommandFromActiveWorld()
        {
            if (string.IsNullOrEmpty(ResourceCommandPath) || !File.Exists(ResourceCommandPath))
            {
                return;
            }

            try
            {
                World world = World.DefaultGameObjectInjectionWorld;
                if (world == null || !world.IsCreated || !Systems.GameStateSystems.GameState.GameStarted)
                {
                    return;
                }

                TryConsumeWsiResourceCommand(world.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Active-world W/S/I command processing failed: " + ex.Message);
            }
        }

        private static void TryConsumeWsiResourceCommand(EntityManager entityManager)
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextResourceCommandReadUtc)
            {
                return;
            }

            NextResourceCommandReadUtc = nowUtc.AddMilliseconds(100);

            List<ResourceCommand> commands;
            if (!ResourceCommand.TryLoadAll(ResourceCommandPath, out commands))
            {
                return;
            }

            try
            {
                if (!CurrentState.Enabled)
                {
                    LogInfo("Ignored " + commands.Count + " resource command(s) because master switch is off.");
                    DeleteResourceCommandFile();
                    return;
                }

                for (int i = 0; i < commands.Count; i++)
                {
                    ResourceCommand command = commands[i];
                    ApplyResourceTarget(entityManager, command.Resource, command.Value);
                }

                DeleteResourceCommandFile();
            }
            catch (Exception ex)
            {
                LogError("Resource command failed: " + ex.Message);
                DeleteResourceCommandFile();
            }
        }

        private static void ApplyResourceTarget(EntityManager entityManager, string resource, int target)
        {
            if (resource == "wood" || resource == "stone" || resource == "iron")
            {
                ApplyWsiResourceTarget(entityManager, resource, target);
                return;
            }

            if (resource == "food")
            {
                SyncCurrentFood(entityManager, target);
                Systems.GameStateSystems.ResourceState state = Systems.GameStateSystems.GameState.ResourceState;
                state.foodValue = Math.Max(0, target);
                Systems.GameStateSystems.GameState.ResourceState = state;
            }
            else if (resource == "souls")
            {
                SyncCurrentSouls(entityManager, target);
                Systems.GameStateSystems.ResourceState state = Systems.GameStateSystems.GameState.ResourceState;
                state.soulsValue = Math.Max(0, target);
                Systems.GameStateSystems.GameState.ResourceState = state;
            }
            else if (resource == "money")
            {
                SyncCurrentMoney(entityManager, target);
                Systems.GameStateSystems.ResourceState state = Systems.GameStateSystems.GameState.ResourceState;
                state.moneyValue = Math.Max(0, target);
                Systems.GameStateSystems.GameState.ResourceState = state;
            }
            else
            {
                throw new InvalidOperationException("Unsupported resource: " + resource);
            }

            RequestOfficialResourceUiRefresh();
            ForceResourcesPanelRefresh();
            LogInfo("Applied resource command " + resource + "=" + target + ".");
        }

        private static void ApplyWsiResourceTarget(EntityManager entityManager, string resource, int target)
        {
            EnsureTrainerWsiStorage(entityManager, 1);

            int hiddenWood = entityManager.GetComponentData<WoodStorage>(TrainerWsiStorageEntity).stored;
            int hiddenStone = entityManager.GetComponentData<StoneStorage>(TrainerWsiStorageEntity).stored;
            int hiddenIron = entityManager.GetComponentData<IronStorage>(TrainerWsiStorageEntity).stored;

            if (resource == "wood")
            {
                hiddenWood = CalculateHiddenForTarget<WoodStorage>(
                    entityManager, target, ReadWoodStored, WriteWoodStored);
            }
            else if (resource == "stone")
            {
                hiddenStone = CalculateHiddenForTarget<StoneStorage>(
                    entityManager, target, ReadStoneStored, WriteStoneStored);
            }
            else if (resource == "iron")
            {
                hiddenIron = CalculateHiddenForTarget<IronStorage>(
                    entityManager, target, ReadIronStored, WriteIronStored);
            }
            else
            {
                throw new InvalidOperationException("Unsupported W/S/I resource: " + resource);
            }

            int hiddenTotal = hiddenWood + hiddenStone + hiddenIron;
            int requiredCapacity = Math.Max(1, hiddenTotal + TrainerWsiStorageHeadroom);
            EnsureTrainerWsiStorage(entityManager, requiredCapacity);

            WoodStorage woodStorage = entityManager.GetComponentData<WoodStorage>(TrainerWsiStorageEntity);
            StoneStorage stoneStorage = entityManager.GetComponentData<StoneStorage>(TrainerWsiStorageEntity);
            IronStorage ironStorage = entityManager.GetComponentData<IronStorage>(TrainerWsiStorageEntity);
            woodStorage.stored = hiddenWood;
            stoneStorage.stored = hiddenStone;
            ironStorage.stored = hiddenIron;
            entityManager.SetComponentData(TrainerWsiStorageEntity, woodStorage);
            entityManager.SetComponentData(TrainerWsiStorageEntity, stoneStorage);
            entityManager.SetComponentData(TrainerWsiStorageEntity, ironStorage);

            int totalWood = SumStorage<WoodStorage>(entityManager, Entity.Null, ReadWoodStored);
            int totalStone = SumStorage<StoneStorage>(entityManager, Entity.Null, ReadStoneStored);
            int totalIron = SumStorage<IronStorage>(entityManager, Entity.Null, ReadIronStored);
            SyncCurrentWood(entityManager, totalWood);
            SyncCurrentStone(entityManager, totalStone);
            SyncCurrentIron(entityManager, totalIron);
            int wsiCapacity = CalculateVisibleWsiCapacity(totalWood, totalStone, totalIron, TrainerWsiStorageHeadroom);
            SyncWsiResourceState(totalWood, totalStone, totalIron, wsiCapacity);
            RequestOfficialResourceUiRefresh();
            ForceResourcesPanelRefresh();

            LogInfo("Applied W/S/I command " + resource + "=" + target +
                    "; totals wood/stone/iron=" + totalWood + "/" + totalStone + "/" + totalIron +
                    ", trainer hidden=" + hiddenWood + "/" + hiddenStone + "/" + hiddenIron +
                    ", trainer capacity=" + TrainerWsiStorageCapacity +
                    ", trainer headroom=" + TrainerWsiStorageHeadroom +
                    ", wsi max=" + wsiCapacity + ".");
        }

        private static void SyncWsiTotalsFromStoragesIfDue(EntityManager entityManager)
        {
            if (!IsTrainerWsiStorageValid(entityManager))
            {
                return;
            }

            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextWsiTotalsSyncUtc)
            {
                return;
            }

            NextWsiTotalsSyncUtc = nowUtc.AddMilliseconds(500);

            int totalWood = SumStorage<WoodStorage>(entityManager, Entity.Null, ReadWoodStored);
            int totalStone = SumStorage<StoneStorage>(entityManager, Entity.Null, ReadStoneStored);
            int totalIron = SumStorage<IronStorage>(entityManager, Entity.Null, ReadIronStored);
            int wsiCapacity = CalculateVisibleWsiCapacity(totalWood, totalStone, totalIron, TrainerWsiStorageHeadroom);

            if (totalWood == LastSyncedWsiWood &&
                totalStone == LastSyncedWsiStone &&
                totalIron == LastSyncedWsiIron &&
                wsiCapacity == LastSyncedWsiCapacity)
            {
                return;
            }

            SyncCurrentWood(entityManager, totalWood);
            SyncCurrentStone(entityManager, totalStone);
            SyncCurrentIron(entityManager, totalIron);
            SyncWsiResourceState(totalWood, totalStone, totalIron, wsiCapacity);
            RequestOfficialResourceUiRefresh();
            ForceResourcesPanelRefresh();

            LastSyncedWsiWood = totalWood;
            LastSyncedWsiStone = totalStone;
            LastSyncedWsiIron = totalIron;
            LastSyncedWsiCapacity = wsiCapacity;

            LogInfo("Synced W/S/I totals from storages: wood/stone/iron=" +
                    totalWood + "/" + totalStone + "/" + totalIron +
                    ", wsi max=" + wsiCapacity + ".");
        }

        private static int CalculateHiddenForTarget<T>(
            EntityManager entityManager,
            int target,
            StorageReader<T> readStored,
            StorageWriter<T> writeStored)
            where T : struct, IComponentData
        {
            target = Math.Max(0, target);
            int realTotal = SumStorage<T>(entityManager, TrainerWsiStorageEntity, readStored);
            if (target < realTotal)
            {
                ReduceStorageToTotal<T>(entityManager, TrainerWsiStorageEntity, target, readStored, writeStored);
                return 0;
            }

            return target - realTotal;
        }

        private static void EnsureTrainerWsiStorage(EntityManager entityManager, int requiredCapacity)
        {
            if (!IsTrainerWsiStorageValid(entityManager))
            {
                DisposeTrainerWsiBlob();
                TrainerWsiStorageEntity = entityManager.CreateEntity(new ComponentType[]
                {
                    ComponentType.ReadWrite(typeof(StorageBase)),
                    ComponentType.ReadWrite(typeof(WoodStorage)),
                    ComponentType.ReadWrite(typeof(StoneStorage)),
                    ComponentType.ReadWrite(typeof(IronStorage))
                });
                TrainerWsiStorageCapacity = 0;
                entityManager.SetComponentData(TrainerWsiStorageEntity, new WoodStorage());
                entityManager.SetComponentData(TrainerWsiStorageEntity, new StoneStorage());
                entityManager.SetComponentData(TrainerWsiStorageEntity, new IronStorage());
                LogInfo("Created hidden W/S/I trainer storage entity " + FormatEntity(TrainerWsiStorageEntity) + ".");
            }

            if (requiredCapacity <= TrainerWsiStorageCapacity)
            {
                return;
            }

            StorageBaseData data = new StorageBaseData();
            data.foodCapacity = 0;
            data.woodStoneIronCapacity = requiredCapacity;
            data.corpseCapacity = 0;
            data.bonesCapacity = 0;
            data.spiritCapacity = 0;

            BlobAssetReference<StorageBaseData> oldBlob = TrainerWsiStorageBlob;
            TrainerWsiStorageBlob = BlobAssetReference<StorageBaseData>.Create(data);
            StorageBase storageBase = new StorageBase();
            storageBase.value = TrainerWsiStorageBlob;
            entityManager.SetComponentData(TrainerWsiStorageEntity, storageBase);
            TrainerWsiStorageCapacity = requiredCapacity;

            if (oldBlob.IsCreated)
            {
                oldBlob.Dispose();
            }

            LogInfo("Hidden W/S/I trainer storage capacity set to " + TrainerWsiStorageCapacity + ".");
        }

        private static bool IsTrainerWsiStorageValid(EntityManager entityManager)
        {
            return TrainerWsiStorageEntity != Entity.Null &&
                   entityManager.Exists(TrainerWsiStorageEntity) &&
                   entityManager.HasComponent<StorageBase>(TrainerWsiStorageEntity) &&
                   entityManager.HasComponent<WoodStorage>(TrainerWsiStorageEntity) &&
                   entityManager.HasComponent<StoneStorage>(TrainerWsiStorageEntity) &&
                   entityManager.HasComponent<IronStorage>(TrainerWsiStorageEntity);
        }

        private static void DisposeTrainerWsiBlob()
        {
            if (TrainerWsiStorageBlob.IsCreated)
            {
                TrainerWsiStorageBlob.Dispose();
            }

            TrainerWsiStorageBlob = default(BlobAssetReference<StorageBaseData>);
            TrainerWsiStorageEntity = Entity.Null;
            TrainerWsiStorageCapacity = 0;
        }

        private static int SumStorage<T>(
            EntityManager entityManager,
            Entity exclude,
            StorageReader<T> readStored)
            where T : struct, IComponentData
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(T));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            int total = 0;
            bool hasExclude = exclude != Entity.Null;

            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    if (hasExclude && entities[i] == exclude)
                    {
                        continue;
                    }

                    T storage = entityManager.GetComponentData<T>(entities[i]);
                    total += Math.Max(0, readStored(storage));
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }

            return total;
        }

        private static void ReduceStorageToTotal<T>(
            EntityManager entityManager,
            Entity exclude,
            int target,
            StorageReader<T> readStored,
            StorageWriter<T> writeStored)
            where T : struct, IComponentData
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(T));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            int total = SumStorage<T>(entityManager, exclude, readStored);
            int toRemove = Math.Max(0, total - Math.Max(0, target));
            bool hasExclude = exclude != Entity.Null;

            try
            {
                for (int i = 0; i < entities.Length && toRemove > 0; i++)
                {
                    if (hasExclude && entities[i] == exclude)
                    {
                        continue;
                    }

                    T storage = entityManager.GetComponentData<T>(entities[i]);
                    int stored = Math.Max(0, readStored(storage));
                    int remove = Math.Min(stored, toRemove);
                    if (remove <= 0)
                    {
                        continue;
                    }

                    storage = writeStored(storage, stored - remove);
                    entityManager.SetComponentData(entities[i], storage);
                    toRemove -= remove;
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentFood(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentFood));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentFood current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentFood>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentWood(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentWood));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentWood current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentWood>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentStone(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentStone));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentStone current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentStone>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentIron(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentIron));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentIron current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentIron>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentSouls(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentSouls));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentSouls current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentSouls>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncCurrentMoney(EntityManager entityManager, int total)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(Components.RawComponents.CurrentMoney));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            total = Math.Max(0, total);
            try
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Components.RawComponents.CurrentMoney current =
                        entityManager.GetComponentData<Components.RawComponents.CurrentMoney>(entities[i]);
                    current.value = total;
                    current.valueContainer.value = total;
                    entityManager.SetComponentData(entities[i], current);
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void SyncWsiResourceState(int wood, int stone, int iron, int wsiCapacity)
        {
            try
            {
                Systems.GameStateSystems.ResourceState state = Systems.GameStateSystems.GameState.ResourceState;
                state.woodValue = wood;
                state.stoneValue = stone;
                state.ironValue = iron;
                state.wsiMaxValue = wsiCapacity;
                Systems.GameStateSystems.GameState.ResourceState = state;
            }
            catch (Exception ex)
            {
                LogError("W/S/I UI state sync failed: " + ex.Message);
            }
        }

        private static void RequestOfficialResourceUiRefresh()
        {
            try
            {
                Systems.GameStateSystems.GameState.UpdateFlag |=
                    Systems.GameStateSystems.GameStateUpdateFlag.Resources |
                    Systems.GameStateSystems.GameStateUpdateFlag.UI;
            }
            catch (Exception ex)
            {
                LogError("Resource UI update flag request failed: " + ex.Message);
            }
        }

        private static int CalculateVisibleWsiCapacity(int wood, int stone, int iron, int headroom)
        {
            int currentTotal = Math.Max(0, wood) + Math.Max(0, stone) + Math.Max(0, iron);
            int existingMax = 0;
            try
            {
                existingMax = Systems.GameStateSystems.GameState.ResourceState.wsiMaxValue;
            }
            catch
            {
                existingMax = 0;
            }

            return Math.Max(existingMax, currentTotal + Math.Max(0, headroom));
        }

        private static void ForceResourcesPanelRefresh()
        {
            Systems.GameStateSystems.ResourceState state = Systems.GameStateSystems.GameState.ResourceState;
            ForceResourcesPanelRefresh(
                state.foodValue,
                state.woodValue,
                state.stoneValue,
                state.ironValue,
                state.soulsValue,
                state.moneyValue,
                state.wsiMaxValue);
        }

        private static void ForceResourcesPanelRefresh(
            int food,
            int wood,
            int stone,
            int iron,
            int souls,
            int money,
            int wsiCapacity)
        {
            List<object> panels = FindResourcePanels();
            if (panels.Count == 0 || LastResourcesPanelUpdateValuesMethod == null)
            {
                LogInfo("W/S/I UI state synced; no ResourcesPanel instance is available yet.");
                return;
            }

            int refreshed = 0;
            try
            {
                for (int i = 0; i < panels.Count; i++)
                {
                    object panel = panels[i];
                    if (panel == null)
                    {
                        continue;
                    }

                    LastResourcesPanelUpdateValuesMethod.Invoke(panel, null);
                    SetPanelText(panel, "_foodText", food.ToString());
                    SetPanelText(panel, "_woodText", wood.ToString());
                    SetPanelText(panel, "_stoneText", stone.ToString());
                    SetPanelText(panel, "_ironText", iron.ToString());
                    SetPanelText(panel, "_soulsText", souls.ToString());
                    SetPanelText(panel, "_moneyText", money.ToString());
                    UpdateWsiSlider(panel, wood, stone, iron, wsiCapacity);
                    refreshed++;
                }

                LogInfo("Forced ResourcesPanel text/slider refresh after resource command; panels=" + refreshed + ".");
            }
            catch (Exception ex)
            {
                LastResourcesPanel = null;
                DateTime nowUtc = DateTime.UtcNow;
                if (nowUtc >= NextResourcesPanelErrorLogUtc)
                {
                    NextResourcesPanelErrorLogUtc = nowUtc.AddSeconds(3);
                    LogError("Forced ResourcesPanel.UpdateValues failed: " + ex.Message);
                }
            }
        }

        private static List<object> FindResourcePanels()
        {
            List<object> panels = new List<object>();
            if (ResourcesPanelType != null)
            {
                UnityEngine.Object[] found = UnityEngine.Object.FindObjectsOfType(ResourcesPanelType);
                for (int i = 0; i < found.Length; i++)
                {
                    if (found[i] != null)
                    {
                        panels.Add(found[i]);
                    }
                }
            }

            if (panels.Count == 0 && LastResourcesPanel != null)
            {
                panels.Add(LastResourcesPanel);
            }

            return panels;
        }

        private static void SetPanelText(object panel, string fieldName, string value)
        {
            object textObject = GetField(panel, fieldName).GetValue(panel);
            if (textObject == null)
            {
                return;
            }

            PropertyInfo textProperty = textObject.GetType().GetProperty("text", BindingFlags.Instance | BindingFlags.Public);
            if (textProperty != null)
            {
                textProperty.SetValue(textObject, value, null);
            }
        }

        private static void UpdateWsiSlider(object panel, int wood, int stone, int iron, int wsiCapacity)
        {
            object slider = GetField(panel, "_wsiSlider").GetValue(panel);
            if (slider == null)
            {
                return;
            }

            MethodInfo updateView = slider.GetType().GetMethod("UpdateView", BindingFlags.Instance | BindingFlags.Public);
            if (updateView == null)
            {
                return;
            }

            updateView.Invoke(slider, new object[]
            {
                (float)wood,
                (float)stone,
                (float)iron,
                (float)Math.Max(1, wsiCapacity)
            });
        }

        private static int ReadWoodStored(WoodStorage storage)
        {
            return storage.stored;
        }

        private static WoodStorage WriteWoodStored(WoodStorage storage, int value)
        {
            storage.stored = value;
            return storage;
        }

        private static int ReadStoneStored(StoneStorage storage)
        {
            return storage.stored;
        }

        private static StoneStorage WriteStoneStored(StoneStorage storage, int value)
        {
            storage.stored = value;
            return storage;
        }

        private static int ReadIronStored(IronStorage storage)
        {
            return storage.stored;
        }

        private static IronStorage WriteIronStored(IronStorage storage, int value)
        {
            storage.stored = value;
            return storage;
        }

        private static void DeleteResourceCommandFile()
        {
            try
            {
                if (!string.IsNullOrEmpty(ResourceCommandPath) && File.Exists(ResourceCommandPath))
                {
                    File.Delete(ResourceCommandPath);
                }
            }
            catch (Exception ex)
            {
                LogError("Resource command delete failed: " + ex.Message);
            }
        }

        private static void ConstructionSystemPrefix(object __instance)
        {
            RefreshStateIfDue();
            TrainerState state = CurrentState;
            if (!state.Enabled || !state.InstantConstruction)
            {
                ConstructionSeenUtc.Clear();
                return;
            }

            SystemBase system = __instance as SystemBase;
            if (system == null)
            {
                return;
            }

            try
            {
                ApplyInstantConstruction(system.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Instant construction failed: " + ex.Message);
            }
        }

        private static void ApplyInstantConstruction(EntityManager entityManager)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(ConstructionWorkCollector));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            DateTime nowUtc = DateTime.UtcNow;
            int candidates = 0;
            int completed = 0;
            int directDone = 0;
            int nativeFinalize = 0;

            try
            {
                HashSet<long> live = new HashSet<long>();
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    long key = EntityKey(entity);
                    live.Add(key);

                    if (entityManager.HasComponent<InRepair>(entity))
                    {
                        continue;
                    }

                    if (!entityManager.HasComponent<InConstruction>(entity) &&
                        !entityManager.HasComponent<InUpgrade>(entity))
                    {
                        continue;
                    }

                    ConstructionWorkCollector collector = entityManager.GetComponentData<ConstructionWorkCollector>(entity);
                    if (collector.WorkAmountRequired <= 0.0f ||
                        collector.WorkAmountDone >= collector.WorkAmountRequired)
                    {
                        continue;
                    }

                    candidates++;
                    DateTime firstSeenUtc;
                    if (!ConstructionSeenUtc.TryGetValue(key, out firstSeenUtc))
                    {
                        ConstructionSeenUtc[key] = nowUtc;
                        continue;
                    }

                    if ((nowUtc - firstSeenUtc).TotalMilliseconds < InstantDelayMs)
                    {
                        continue;
                    }

                    collector.WorkAmountDone = collector.WorkAmountRequired;
                    if (IsResourceProductionConstruction(entityManager, entity))
                    {
                        nativeFinalize++;
                    }
                    else
                    {
                        collector.ConstructionState = ConstructionState.Done;
                        directDone++;
                    }

                    entityManager.SetComponentData(entity, collector);
                    FillConstructionHealth(entityManager, entity);
                    completed++;
                }

                PruneConstructionSeen(live);
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }

            if ((completed > 0 || candidates > 0) && nowUtc >= NextConstructionLogUtc)
            {
                NextConstructionLogUtc = nowUtc.AddSeconds(1);
                LogInfo("Instant construction candidates=" + candidates +
                        ", completed=" + completed +
                        ", directDone=" + directDone +
                        ", nativeFinalize=" + nativeFinalize + ".");
            }
        }

        private static bool IsResourceProductionConstruction(EntityManager entityManager, Entity entity)
        {
            return entityManager.HasComponent<ProducerBase>(entity) ||
                   entityManager.HasComponent<SelfProducer>(entity) ||
                   entityManager.HasComponent<ResourceSource>(entity) ||
                   entityManager.HasComponent<ResourceSourceReference>(entity) ||
                   entityManager.HasComponent<StoneMine>(entity) ||
                   entityManager.HasComponent<InfiniteStoneMine>(entity) ||
                   entityManager.HasComponent<IronMine>(entity) ||
                   entityManager.HasComponent<InfiniteIronMine>(entity) ||
                   entityManager.HasComponent<StoneCutter>(entity);
        }

        private static void FillConstructionHealth(EntityManager entityManager, Entity entity)
        {
            if (!entityManager.HasComponent<Health>(entity) || !entityManager.HasComponent<HealthBase>(entity))
            {
                return;
            }

            HealthBase healthBase = entityManager.GetComponentData<HealthBase>(entity);
            float maxHealth = healthBase.GetData().maxHealth * healthBase.GetMaxHealthMultiplier();
            if (maxHealth <= 0.0f)
            {
                return;
            }

            Health health = entityManager.GetComponentData<Health>(entity);
            health.currentHealth = maxHealth;
            entityManager.SetComponentData(entity, health);

            if (entityManager.HasComponent<HealthBarReference>(entity))
            {
                HealthBarReference reference = entityManager.GetComponentData<HealthBarReference>(entity);
                if (reference.Bar != Entity.Null && entityManager.HasComponent<BarFillPercent>(reference.Bar))
                {
                    BarFillPercent fill = entityManager.GetComponentData<BarFillPercent>(reference.Bar);
                    fill.Value = 1.0f;
                    entityManager.SetComponentData(reference.Bar, fill);
                }
            }
        }

        private static void ResearchSystemPrefix(object __instance)
        {
            RefreshStateIfDue();
            TrainerState state = CurrentState;
            if (!state.Enabled || !state.InstantResearch)
            {
                LastResearchId = -1;
                return;
            }

            global::Systems.ResearchSystem system = __instance as global::Systems.ResearchSystem;
            if (system == null)
            {
                return;
            }

            try
            {
                object singleton = GetManagedSingleton(system, typeof(ResearchContainerSingleton));
                object container = GetField(singleton, "Container").GetValue(singleton);
                object currentResearchRef = GetField(container, "CurrentResearchId").GetValue(container);
                object progressRef = GetField(container, "ResearchProgress").GetValue(container);

                int researchId = GetNativeReferenceValue<int>(currentResearchRef);
                if (researchId <= 0)
                {
                    LastResearchId = -1;
                    return;
                }

                DateTime nowUtc = DateTime.UtcNow;
                if (researchId != LastResearchId)
                {
                    LastResearchId = researchId;
                    LastResearchSeenUtc = nowUtc;
                    LogInfo("Instant research detected research id " + researchId + ".");
                    return;
                }

                if ((nowUtc - LastResearchSeenUtc).TotalMilliseconds < InstantDelayMs)
                {
                    return;
                }

                float progress = GetNativeReferenceValue<float>(progressRef);
                if (progress < 1.0f)
                {
                    SetNativeReferenceValue(progressRef, 1.0f);
                    LogInfo("Instant research pushed id " + researchId + " progress from " + progress.ToString("0.000") + " to 1.000.");
                }
            }
            catch (Exception ex)
            {
                DateTime nowUtc = DateTime.UtcNow;
                if (nowUtc >= NextResearchErrorLogUtc)
                {
                    NextResearchErrorLogUtc = nowUtc.AddSeconds(3);
                    LogError("Instant research failed: " + ex.Message);
                }
            }
        }

        private static void ArmyTrainingSystemPrefix(object __instance)
        {
            RefreshStateIfDue();
            TrainerState state = CurrentState;
            if (!state.Enabled || !state.InstantTraining)
            {
                TrainingSeenUtc.Clear();
                return;
            }

            SystemBase system = __instance as SystemBase;
            if (system == null)
            {
                return;
            }

            try
            {
                ApplyInstantTraining(system.EntityManager);
            }
            catch (Exception ex)
            {
                LogError("Instant training failed: " + ex.Message);
            }
        }

        private static void ApplyInstantTraining(EntityManager entityManager)
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(UnitTrainingProcess));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            DateTime nowUtc = DateTime.UtcNow;
            int candidates = 0;
            int completed = 0;

            try
            {
                HashSet<long> live = new HashSet<long>();
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity trainer = entities[i];
                    if (!entityManager.HasComponent<UnitTrainingProcess>(trainer))
                    {
                        continue;
                    }

                    DynamicBuffer<UnitTrainingProcess> buffer = entityManager.GetBuffer<UnitTrainingProcess>(trainer);
                    for (int processIndex = 0; processIndex < buffer.Length; processIndex++)
                    {
                        UnitTrainingProcess process = buffer[processIndex];
                        if (process.TimeToTrainingEnd <= 0.0f)
                        {
                            continue;
                        }

                        long key = TrainingKey(trainer, processIndex, process);
                        live.Add(key);
                        candidates++;

                        DateTime firstSeenUtc;
                        if (!TrainingSeenUtc.TryGetValue(key, out firstSeenUtc))
                        {
                            TrainingSeenUtc[key] = nowUtc;
                            continue;
                        }

                        if ((nowUtc - firstSeenUtc).TotalMilliseconds < InstantDelayMs)
                        {
                            continue;
                        }

                        process.TimeToTrainingEnd = 0.0f;
                        buffer[processIndex] = process;
                        completed++;
                    }
                }

                PruneTrainingSeen(live);
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }

            if ((completed > 0 || candidates > 0) && nowUtc >= NextTrainingLogUtc)
            {
                NextTrainingLogUtc = nowUtc.AddSeconds(1);
                LogInfo("Instant training candidates=" + candidates + ", completed=" + completed + ".");
            }
        }

        private static long TrainingKey(Entity trainer, int processIndex, UnitTrainingProcess process)
        {
            unchecked
            {
                long key = EntityKey(trainer);
                key = (key * 397) ^ processIndex;
                key = (key * 397) ^ process.UnitId;
                key = (key * 397) ^ EntityKey(process.CitizenEntity);
                return key;
            }
        }

        private static void PruneConstructionSeen(HashSet<long> live)
        {
            List<long> remove = null;
            foreach (long key in ConstructionSeenUtc.Keys)
            {
                if (!live.Contains(key))
                {
                    if (remove == null)
                    {
                        remove = new List<long>();
                    }

                    remove.Add(key);
                }
            }

            if (remove == null)
            {
                return;
            }

            for (int i = 0; i < remove.Count; i++)
            {
                ConstructionSeenUtc.Remove(remove[i]);
            }
        }

        private static void PruneTrainingSeen(HashSet<long> live)
        {
            List<long> remove = null;
            foreach (long key in TrainingSeenUtc.Keys)
            {
                if (!live.Contains(key))
                {
                    if (remove == null)
                    {
                        remove = new List<long>();
                    }

                    remove.Add(key);
                }
            }

            if (remove == null)
            {
                return;
            }

            for (int i = 0; i < remove.Count; i++)
            {
                TrainingSeenUtc.Remove(remove[i]);
            }
        }

        private static object GetManagedSingleton(SystemBase system, Type singletonType)
        {
            if (ManagedGetSingletonMethod == null)
            {
                MethodInfo[] methods = typeof(ComponentSystemBaseManagedComponentExtensions).GetMethods(
                    BindingFlags.Public | BindingFlags.Static);
                for (int i = 0; i < methods.Length; i++)
                {
                    MethodInfo method = methods[i];
                    if (method.Name == "GetSingleton" &&
                        method.IsGenericMethodDefinition &&
                        method.GetParameters().Length == 1)
                    {
                        ManagedGetSingletonMethod = method;
                        break;
                    }
                }
            }

            if (ManagedGetSingletonMethod == null)
            {
                throw new MissingMethodException("ComponentSystemBaseManagedComponentExtensions.GetSingleton");
            }

            return ManagedGetSingletonMethod.MakeGenericMethod(singletonType).Invoke(null, new object[] { system });
        }

        private static FieldInfo GetField(object instance, string fieldName)
        {
            Type type = instance.GetType();
            string key = type.FullName + "." + fieldName;
            FieldInfo field;
            if (!FieldCache.TryGetValue(key, out field))
            {
                field = type.GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (field == null)
                {
                    throw new MissingFieldException(type.FullName, fieldName);
                }

                FieldCache[key] = field;
            }

            return field;
        }

        private static T GetNativeReferenceValue<T>(object nativeReference)
        {
            PropertyInfo valueProperty = nativeReference.GetType().GetProperty("Value");
            if (valueProperty == null)
            {
                throw new InvalidOperationException("NativeReference.Value not found.");
            }

            return (T)valueProperty.GetValue(nativeReference, null);
        }

        private static void SetNativeReferenceValue(object nativeReference, float value)
        {
            PropertyInfo valueProperty = nativeReference.GetType().GetProperty("Value");
            if (valueProperty == null)
            {
                throw new InvalidOperationException("NativeReference.Value not found.");
            }

            valueProperty.SetValue(nativeReference, value, null);
        }

        private static void RefreshStateIfDue()
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextStateReadUtc)
            {
                return;
            }

            NextStateReadUtc = nowUtc.AddMilliseconds(200);
            TrainerState next = TrainerState.Load(StatePath);
            TrainerState previous = CurrentState;
            CurrentState = next;

            if (!next.Equals(previous))
            {
                LogInfo("State: enabled=" + next.Enabled +
                        ", instantConstruction=" + next.InstantConstruction +
                        ", instantResearch=" + next.InstantResearch +
                        ", instantTraining=" + next.InstantTraining + ".");
            }
        }

        private static void RefreshSummonOverrideIfDue()
        {
            DateTime nowUtc = DateTime.UtcNow;
            if (nowUtc < NextSummonCommandReadUtc)
            {
                return;
            }

            NextSummonCommandReadUtc = nowUtc.AddMilliseconds(200);
            SummonOverride next = SummonOverride.Load(SummonCommandPath);
            SummonOverride previous = CurrentSummonOverride;
            CurrentSummonOverride = next;

            if (!next.Equals(previous))
            {
                LogInfo("Summon override: enabled=" + next.Enabled +
                        ", quantity=" + next.Quantity +
                        ", durationSeconds=" + next.DurationSeconds +
                        ", units=" + next.UnitTypeIds.Count + ".");
            }
        }

        private static void LogStorages<T>(EntityManager entityManager, string name, Func<T, int> readStored)
            where T : struct, IComponentData
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(T));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            try
            {
                LogInfo(name + " count=" + entities.Length + ".");
                for (int i = 0; i < entities.Length; i++)
                {
                    T component = entityManager.GetComponentData<T>(entities[i]);
                    LogInfo(name + "[" + i + "] entity=" + FormatEntity(entities[i]) +
                            " addr=" + FormatAddress(GetRawAddress<T>(entityManager, entities[i])) +
                            " stored=" + readStored(component) + ".");
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static void LogCurrent<T>(EntityManager entityManager, string name)
            where T : struct, IComponentData
        {
            EntityQuery query = entityManager.CreateEntityQuery(typeof(T));
            NativeArray<Entity> entities = query.ToEntityArray(Allocator.Temp);
            try
            {
                LogInfo(name + " count=" + entities.Length + ".");
                for (int i = 0; i < entities.Length; i++)
                {
                    long address = GetRawAddress<T>(entityManager, entities[i]);
                    LogInfo(name + "[" + i + "] entity=" + FormatEntity(entities[i]) +
                            " component=" + FormatAddress(address) +
                            " currentValueField=" + FormatAddress(address + 4) + ".");
                }
            }
            finally
            {
                entities.Dispose();
                query.Dispose();
            }
        }

        private static int GetWoodStored(WoodStorage storage)
        {
            return storage.stored;
        }

        private static int GetStoneStored(StoneStorage storage)
        {
            return storage.stored;
        }

        private static int GetIronStored(IronStorage storage)
        {
            return storage.stored;
        }

        private static int GetFoodStored(FoodStorage storage)
        {
            return storage.stored;
        }

        private static unsafe long GetRawAddress<T>(EntityManager entityManager, Entity entity) where T : struct, IComponentData
        {
            if (GetComponentDataRawRwMethod == null)
            {
                return 0;
            }

            int typeIndex = TypeManager.GetTypeIndex(typeof(T));
            object boxedPointer = GetComponentDataRawRwMethod.Invoke(entityManager, new object[] { entity, typeIndex });
            if (boxedPointer == null)
            {
                return 0;
            }

            void* pointer = Pointer.Unbox(boxedPointer);
            return (long)pointer;
        }

        private static long EntityKey(Entity entity)
        {
            return ((long)entity.Index << 32) ^ (uint)entity.Version;
        }

        private static string FormatEntity(Entity entity)
        {
            return entity.Index + ":" + entity.Version;
        }

        private static string FormatAddress(long address)
        {
            return address == 0 ? "<none>" : "0x" + address.ToString("X");
        }

        private static void LogInfo(string message)
        {
            if (Log != null)
            {
                Log.LogInfo(message);
            }
        }

        private static void LogError(string message)
        {
            if (Log != null)
            {
                Log.LogError(message);
            }
        }

        private sealed class TrainerState
        {
            public bool Enabled;
            public bool InstantConstruction;
            public bool InstantResearch;
            public bool InstantTraining;

            public static TrainerState Load(string path)
            {
                TrainerState state = new TrainerState();
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    return state;
                }

                try
                {
                    string[] lines;
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        lines = reader.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                    }

                    for (int i = 0; i < lines.Length; i++)
                    {
                        string line = lines[i].Trim();
                        int separator = line.IndexOf('=');
                        if (separator <= 0)
                        {
                            continue;
                        }

                        string key = line.Substring(0, separator).Trim().ToLowerInvariant();
                        string value = line.Substring(separator + 1).Trim();
                        bool enabled = ParseBool(value);
                        switch (key)
                        {
                            case "enabled":
                                state.Enabled = enabled;
                                break;
                            case "instantconstruction":
                                state.InstantConstruction = enabled;
                                break;
                            case "instantresearch":
                                state.InstantResearch = enabled;
                                break;
                            case "instanttraining":
                                state.InstantTraining = enabled;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogError("State read failed: " + ex.Message);
                }

                return state;
            }

            public override bool Equals(object obj)
            {
                TrainerState other = obj as TrainerState;
                if (other == null)
                {
                    return false;
                }

                return Enabled == other.Enabled &&
                       InstantConstruction == other.InstantConstruction &&
                       InstantResearch == other.InstantResearch &&
                       InstantTraining == other.InstantTraining;
            }

            public override int GetHashCode()
            {
                int hash = Enabled ? 1 : 0;
                hash = (hash * 397) ^ (InstantConstruction ? 1 : 0);
                hash = (hash * 397) ^ (InstantResearch ? 1 : 0);
                hash = (hash * 397) ^ (InstantTraining ? 1 : 0);
                return hash;
            }

            private static bool ParseBool(string value)
            {
                return value == "1" ||
                       string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) ||
                       string.Equals(value, "on", StringComparison.OrdinalIgnoreCase);
            }
        }

        private sealed class SummonOverride
        {
            public long Id;
            public bool Enabled;
            public int Quantity;
            public int DurationSeconds = 300;
            public List<int> UnitTypeIds = new List<int>();

            public static SummonOverride Load(string path)
            {
                SummonOverride summon = new SummonOverride();
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    return summon;
                }

                try
                {
                    string[] lines;
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        lines = reader.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                    }

                    for (int i = 0; i < lines.Length; i++)
                    {
                        string line = lines[i].Trim();
                        int separator = line.IndexOf('=');
                        if (separator <= 0)
                        {
                            continue;
                        }

                        string key = line.Substring(0, separator).Trim().ToLowerInvariant();
                        string value = line.Substring(separator + 1).Trim();
                        switch (key)
                        {
                            case "id":
                                long.TryParse(value, out summon.Id);
                                break;
                            case "enabled":
                                summon.Enabled = ParseBool(value);
                                break;
                            case "quantity":
                                summon.Quantity = ParseInt(value, 0, 0, 200);
                                break;
                            case "durationseconds":
                                summon.DurationSeconds = ParseInt(value, 300, 0, 99999);
                                break;
                            case "units":
                                summon.UnitTypeIds = ParseUnitIds(value);
                                break;
                        }
                    }

                    if (summon.Quantity <= 0 || summon.UnitTypeIds.Count == 0)
                    {
                        summon.Enabled = false;
                    }
                }
                catch (Exception ex)
                {
                    LogError("Summon override read failed: " + ex.Message);
                }

                return summon;
            }

            public override bool Equals(object obj)
            {
                SummonOverride other = obj as SummonOverride;
                if (other == null)
                {
                    return false;
                }

                if (Id != other.Id ||
                    Enabled != other.Enabled ||
                    Quantity != other.Quantity ||
                    DurationSeconds != other.DurationSeconds ||
                    UnitTypeIds.Count != other.UnitTypeIds.Count)
                {
                    return false;
                }

                for (int i = 0; i < UnitTypeIds.Count; i++)
                {
                    if (UnitTypeIds[i] != other.UnitTypeIds[i])
                    {
                        return false;
                    }
                }

                return true;
            }

            public override int GetHashCode()
            {
                int hash = Id.GetHashCode();
                hash = (hash * 397) ^ (Enabled ? 1 : 0);
                hash = (hash * 397) ^ Quantity;
                hash = (hash * 397) ^ DurationSeconds;
                for (int i = 0; i < UnitTypeIds.Count; i++)
                {
                    hash = (hash * 397) ^ UnitTypeIds[i];
                }

                return hash;
            }

            private static bool ParseBool(string value)
            {
                return value == "1" ||
                       string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) ||
                       string.Equals(value, "on", StringComparison.OrdinalIgnoreCase);
            }

            private static int ParseInt(string value, int fallback, int minimum, int maximum)
            {
                int parsed;
                if (!int.TryParse(value, out parsed))
                {
                    return fallback;
                }

                return Math.Max(minimum, Math.Min(maximum, parsed));
            }

            private static List<int> ParseUnitIds(string value)
            {
                List<int> result = new List<int>();
                if (string.IsNullOrEmpty(value))
                {
                    return result;
                }

                string[] parts = value.Split(',');
                for (int i = 0; i < parts.Length; i++)
                {
                    int parsed;
                    if (int.TryParse(parts[i].Trim(), out parsed) && parsed > 0)
                    {
                        result.Add(parsed);
                    }
                }

                return result;
            }
        }

        private sealed class ResourceCommand
        {
            public string Resource;
            public int Value;

            public static bool TryLoadAll(string path, out List<ResourceCommand> commands)
            {
                commands = null;
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    return false;
                }

                try
                {
                    string[] lines;
                    using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        lines = reader.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
                    }

                    commands = new List<ResourceCommand>();
                    Dictionary<string, string> legacyValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        string line = lines[i].Trim();
                        if (line.Length == 0)
                        {
                            continue;
                        }

                        string[] parts = line.Split('|');
                        if (parts.Length >= 3)
                        {
                            AddParsedCommand(commands, parts[1], parts[2]);
                            continue;
                        }

                        int separator = line.IndexOf('=');
                        if (separator <= 0)
                        {
                            continue;
                        }

                        legacyValues[line.Substring(0, separator).Trim()] = line.Substring(separator + 1).Trim();
                    }

                    if (commands.Count == 0 && legacyValues.Count > 0)
                    {
                        string resource;
                        string valueText;
                        if (legacyValues.TryGetValue("resource", out resource) &&
                            legacyValues.TryGetValue("value", out valueText))
                        {
                            AddParsedCommand(commands, resource, valueText);
                        }
                    }

                    if (commands.Count == 0)
                    {
                        LogError("Invalid resource command file.");
                        DeleteResourceCommandFile();
                        return false;
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    LogError("Resource command read failed: " + ex.Message);
                    return false;
                }
            }

            private static void AddParsedCommand(List<ResourceCommand> commands, string resourceText, string valueText)
            {
                string resource = resourceText.Trim().ToLowerInvariant();
                if (resource != "food" &&
                    resource != "wood" &&
                    resource != "stone" &&
                    resource != "iron" &&
                    resource != "souls" &&
                    resource != "money")
                {
                    LogError("Unsupported resource command: " + resource);
                    return;
                }

                int value;
                if (!int.TryParse(valueText.Trim(), out value))
                {
                    LogError("Invalid resource command value for " + resource + ": " + valueText);
                    return;
                }

                ResourceCommand command = new ResourceCommand();
                command.Resource = resource;
                command.Value = Math.Max(0, Math.Min(999999, value));
                commands.Add(command);
            }
        }

    }
}
