using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Globalization;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace DinaoExternalTrainer
{
    internal static class Program
    {
        internal const string TrainerVersion = "A1.0 Stable";
        private const string ProcessName = "Diplomacy is Not an Option";
        private const string DefaultLogPath = @"X:\GAME\Diplomacy is Not an Option\BepInEx\LogOutput.log";
        private const string DefaultStatePath = @"X:\GAME\Diplomacy is Not an Option\BepInEx\config\DinaoExternalTrainer.state.txt";
        private const string DefaultResourceCommandPath = @"X:\GAME\Diplomacy is Not an Option\BepInEx\config\DinaoExternalTrainer.resource.txt";
        private const string DefaultSummonCommandPath = @"X:\GAME\Diplomacy is Not an Option\BepInEx\config\DinaoExternalTrainer.summon.txt";
        private const string DefaultUnitCatalogPath = @"X:\GAME\Diplomacy is Not an Option\BepInEx\config\DinaoExternalTrainer.units.txt";

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TrainerForm(DefaultLogPath, DefaultStatePath, DefaultResourceCommandPath, DefaultSummonCommandPath, DefaultUnitCatalogPath));
        }

        internal static Process FindGameProcess()
        {
            Process[] processes = Process.GetProcessesByName(ProcessName);
            if (processes.Length == 0)
            {
                throw new InvalidOperationException("Game process not found.");
            }

            return processes[0];
        }
    }

    internal sealed class TrainerForm : Form
    {
        private const int VkNumpad0 = 0x60;
        private const int VkNumpad1 = 0x61;
        private const int VkNumpad2 = 0x62;
        private const int VkNumpad3 = 0x63;
        private const int VkNumpad4 = 0x64;
        private const int VkNumpad5 = 0x65;
        private const int VkNumpad6 = 0x66;
        private const int VkNumpad7 = 0x67;
        private const int VkNumpad8 = 0x68;
        private const int VkNumpad9 = 0x69;
        private const int VkNumpadMultiply = 0x6A;
        private const int VkNumpadDivide = 0x6F;
        private const int VkNumpadDecimal = 0x6E;

        private readonly string _logPath;
        private readonly string _statePath;
        private readonly string _resourceCommandPath;
        private readonly string _summonCommandPath;
        private readonly string _unitCatalogPath;
        private readonly string _unitReviewPath;
        private readonly string _configPath;
        private readonly TrainerConfig _config;
        private readonly Dictionary<string, NumericUpDown> _inputs =
            new Dictionary<string, NumericUpDown>(StringComparer.OrdinalIgnoreCase);

        private readonly bool[] _wasDown = new bool[12];
        private readonly Timer _hotkeyTimer = new Timer();
        private CheckBox _enabledCheckBox;
        private CheckBox _nightModeCheckBox;
        private CheckBox _instantConstructionCheckBox;
        private CheckBox _instantResearchCheckBox;
        private CheckBox _instantTrainingCheckBox;
        private CheckedListBox _friendlySummonList;
        private CheckedListBox _enemySummonList;
        private Button _friendlySelectAllButton;
        private Button _enemySelectAllButton;
        private Button _topMostButton;
        private NumericUpDown _summonQuantityInput;
        private NumericUpDown _summonDurationInput;
        private Button _summonApplyButton;
        private Label _statusLabel;
        private bool _summonOverrideActive;
        private bool _isLoadingConfig;

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int virtualKey);

        public TrainerForm(string logPath, string statePath, string resourceCommandPath, string summonCommandPath, string unitCatalogPath)
        {
            _logPath = logPath;
            _statePath = statePath;
            _resourceCommandPath = resourceCommandPath;
            _summonCommandPath = summonCommandPath;
            _unitCatalogPath = unitCatalogPath;
            _unitReviewPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "中英对照表_ID排序输出.txt"));
            _configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DinaoExternalTrainer.config.txt");
            _config = TrainerConfig.Load(_configPath);

            Text = "DINAO External Trainer " + Program.TrainerVersion;
            Font = new Font("Segoe UI", 9F);
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            MinimizeBox = true;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1040, 430);
            MinimumSize = new Size(900, 390);

            BuildUi();
            _isLoadingConfig = true;
            try
            {
                ApplyConfigToUi();
            }
            finally
            {
                _isLoadingConfig = false;
            }

            SaveUiToConfig();
            WriteStateFile();
            try
            {
                WriteSummonCommand(0, 300, new List<int>());
            }
            catch
            {
            }

            PlayStartup();

            _hotkeyTimer.Interval = 50;
            _hotkeyTimer.Tick += HotkeyTimerTick;
            _hotkeyTimer.Start();

            FormClosing += OnFormClosing;
        }

        private void BuildUi()
        {
            Panel root = new Panel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(12);
            Controls.Add(root);

            _enabledCheckBox = new CheckBox();
            _enabledCheckBox.Text = "Numpad. master switch";
            _enabledCheckBox.AutoSize = true;
            _enabledCheckBox.CheckedChanged += delegate { SaveUiToConfig(); WriteStateFile(); };
            root.Controls.Add(_enabledCheckBox);

            _nightModeCheckBox = new CheckBox();
            _nightModeCheckBox.Text = "Night mode";
            _nightModeCheckBox.AutoSize = true;
            _nightModeCheckBox.Left = 210;
            _nightModeCheckBox.Top = 0;
            _nightModeCheckBox.CheckedChanged += delegate { SaveUiToConfig(); ApplyTheme(); };
            root.Controls.Add(_nightModeCheckBox);

            _topMostButton = new Button();
            _topMostButton.Text = "Top";
            _topMostButton.Left = 320;
            _topMostButton.Top = -2;
            _topMostButton.Width = 64;
            _topMostButton.Height = 26;
            _topMostButton.Click += delegate { ToggleTopMost(); };
            root.Controls.Add(_topMostButton);

            TableLayoutPanel table = new TableLayoutPanel();
            table.Left = 0;
            table.Top = 34;
            table.Width = 404;
            table.Height = 168;
            table.ColumnCount = 3;
            table.RowCount = 6;
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            table.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            root.Controls.Add(table);

            AddResourceRow(table, 0, "Numpad1 Wood", "wood", "Set");
            AddResourceRow(table, 1, "Numpad2 Stone", "stone", "Set");
            AddResourceRow(table, 2, "Numpad3 Iron", "iron", "Set");
            AddResourceRow(table, 3, "Numpad4 Food", "food", "Set");
            AddResourceRow(table, 4, "Numpad5 Souls", "souls", "Set");
            AddResourceRow(table, 5, "Numpad6 Gold", "money", "Set");

            _instantConstructionCheckBox = new CheckBox();
            _instantConstructionCheckBox.Text = "Numpad7 instant build/upgrade";
            _instantConstructionCheckBox.AutoSize = true;
            _instantConstructionCheckBox.Left = 0;
            _instantConstructionCheckBox.Top = 218;
            _instantConstructionCheckBox.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _instantConstructionCheckBox.CheckedChanged += delegate { SaveUiToConfig(); WriteStateFile(); };
            root.Controls.Add(_instantConstructionCheckBox);

            _instantResearchCheckBox = new CheckBox();
            _instantResearchCheckBox.Text = "Numpad8 instant research";
            _instantResearchCheckBox.AutoSize = true;
            _instantResearchCheckBox.Left = 0;
            _instantResearchCheckBox.Top = 244;
            _instantResearchCheckBox.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _instantResearchCheckBox.CheckedChanged += delegate { SaveUiToConfig(); WriteStateFile(); };
            root.Controls.Add(_instantResearchCheckBox);

            _instantTrainingCheckBox = new CheckBox();
            _instantTrainingCheckBox.Text = "Numpad9 instant training";
            _instantTrainingCheckBox.AutoSize = true;
            _instantTrainingCheckBox.Left = 0;
            _instantTrainingCheckBox.Top = 270;
            _instantTrainingCheckBox.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _instantTrainingCheckBox.CheckedChanged += delegate { SaveUiToConfig(); WriteStateFile(); };
            root.Controls.Add(_instantTrainingCheckBox);

            BuildSummonUi(root);

            _statusLabel = new Label();
            _statusLabel.Left = 0;
            _statusLabel.Top = 378;
            _statusLabel.Width = 1004;
            _statusLabel.Height = 36;
            _statusLabel.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            _statusLabel.Text = Program.TrainerVersion + " ready. Turn on Numpad. before using effects.";
            root.Controls.Add(_statusLabel);
        }

        private void BuildSummonUi(Control root)
        {
            GroupBox summonGroup = new GroupBox();
            summonGroup.Text = "Summon";
            summonGroup.Left = 430;
            summonGroup.Top = 28;
            summonGroup.Width = 574;
            summonGroup.Height = 310;
            summonGroup.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            root.Controls.Add(summonGroup);

            Label friendlyLabel = new Label();
            friendlyLabel.Text = "Player";
            friendlyLabel.Left = 12;
            friendlyLabel.Top = 22;
            friendlyLabel.Width = 130;
            friendlyLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            summonGroup.Controls.Add(friendlyLabel);

            _friendlySelectAllButton = new Button();
            _friendlySelectAllButton.Text = "All/Clear";
            _friendlySelectAllButton.Left = 172;
            _friendlySelectAllButton.Top = 17;
            _friendlySelectAllButton.Width = 100;
            _friendlySelectAllButton.Height = 24;
            _friendlySelectAllButton.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            _friendlySelectAllButton.Click += delegate { ToggleSummonListChecks(_friendlySummonList); };
            summonGroup.Controls.Add(_friendlySelectAllButton);

            Label enemyLabel = new Label();
            enemyLabel.Text = "Enemy";
            enemyLabel.Left = 292;
            enemyLabel.Top = 22;
            enemyLabel.Width = 130;
            enemyLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            summonGroup.Controls.Add(enemyLabel);

            _enemySelectAllButton = new Button();
            _enemySelectAllButton.Text = "All/Clear";
            _enemySelectAllButton.Left = 462;
            _enemySelectAllButton.Top = 17;
            _enemySelectAllButton.Width = 100;
            _enemySelectAllButton.Height = 24;
            _enemySelectAllButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _enemySelectAllButton.Click += delegate { ToggleSummonListChecks(_enemySummonList); };
            summonGroup.Controls.Add(_enemySelectAllButton);

            _friendlySummonList = new CheckedListBox();
            _friendlySummonList.Left = 12;
            _friendlySummonList.Top = 42;
            _friendlySummonList.Width = 260;
            _friendlySummonList.Height = 195;
            _friendlySummonList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            _friendlySummonList.CheckOnClick = true;
            _friendlySummonList.ItemCheck += SummonListItemCheck;
            SummonUnit[] friendlyUnits = SummonUnitCatalog.LoadByFaction(_unitCatalogPath, _unitReviewPath, SummonFaction.Player);
            for (int i = 0; i < friendlyUnits.Length; i++)
            {
                _friendlySummonList.Items.Add(friendlyUnits[i]);
            }
            summonGroup.Controls.Add(_friendlySummonList);

            _enemySummonList = new CheckedListBox();
            _enemySummonList.Left = 292;
            _enemySummonList.Top = 42;
            _enemySummonList.Width = 270;
            _enemySummonList.Height = 195;
            _enemySummonList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            _enemySummonList.CheckOnClick = true;
            _enemySummonList.ItemCheck += SummonListItemCheck;
            SummonUnit[] enemyUnits = SummonUnitCatalog.LoadByFaction(_unitCatalogPath, _unitReviewPath, SummonFaction.Enemy);
            for (int i = 0; i < enemyUnits.Length; i++)
            {
                _enemySummonList.Items.Add(enemyUnits[i]);
            }
            summonGroup.Controls.Add(_enemySummonList);

            Label quantityLabel = new Label();
            quantityLabel.Text = "Quantity";
            quantityLabel.Left = 12;
            quantityLabel.Top = 246;
            quantityLabel.Width = 62;
            quantityLabel.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            summonGroup.Controls.Add(quantityLabel);

            _summonQuantityInput = new NumericUpDown();
            _summonQuantityInput.Minimum = 0;
            _summonQuantityInput.Maximum = 200;
            _summonQuantityInput.Left = 78;
            _summonQuantityInput.Top = 242;
            _summonQuantityInput.Width = 62;
            _summonQuantityInput.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _summonQuantityInput.ValueChanged += delegate { SaveUiToConfig(); };
            summonGroup.Controls.Add(_summonQuantityInput);

            Label durationLabel = new Label();
            durationLabel.Text = "Seconds";
            durationLabel.Left = 150;
            durationLabel.Top = 246;
            durationLabel.Width = 58;
            durationLabel.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            summonGroup.Controls.Add(durationLabel);

            _summonDurationInput = new NumericUpDown();
            _summonDurationInput.Minimum = 0;
            _summonDurationInput.Maximum = 99999;
            _summonDurationInput.Left = 212;
            _summonDurationInput.Top = 242;
            _summonDurationInput.Width = 70;
            _summonDurationInput.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            _summonDurationInput.ValueChanged += delegate { SaveUiToConfig(); };
            summonGroup.Controls.Add(_summonDurationInput);

            _summonApplyButton = new Button();
            _summonApplyButton.Text = "Numpad* Apply";
            _summonApplyButton.Left = 12;
            _summonApplyButton.Top = 276;
            _summonApplyButton.Width = 155;
            _summonApplyButton.Height = 28;
            _summonApplyButton.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            _summonApplyButton.Click += delegate { ToggleSummonOverride(); };
            summonGroup.Controls.Add(_summonApplyButton);

            Button clearButton = new Button();
            clearButton.Text = "Numpad/ Clear";
            clearButton.Left = 174;
            clearButton.Top = 276;
            clearButton.Width = 108;
            clearButton.Height = 28;
            clearButton.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            clearButton.Click += delegate { ClearSummonOverride(); };
            summonGroup.Controls.Add(clearButton);
        }

        private void AddResourceRow(TableLayoutPanel table, int row, string labelText, string resource, string buttonText)
        {
            Label label = new Label();
            label.Text = labelText;
            label.Dock = DockStyle.Fill;
            label.TextAlign = ContentAlignment.MiddleLeft;
            table.Controls.Add(label, 0, row);

            NumericUpDown input = new NumericUpDown();
            input.Minimum = 0;
            input.Maximum = 999999;
            input.Increment = resource == "souls" ? 10 : 100;
            input.Dock = DockStyle.Fill;
            input.ValueChanged += delegate { SaveUiToConfig(); };
            _inputs[resource] = input;
            table.Controls.Add(input, 1, row);

            Button button = new Button();
            button.Text = buttonText;
            button.Dock = DockStyle.Fill;
            button.Tag = resource;
            button.Click += delegate { TrySetResource(resource); };
            table.Controls.Add(button, 2, row);
        }

        private void ApplyConfigToUi()
        {
            _enabledCheckBox.Checked = false;
            _nightModeCheckBox.Checked = _config.NightMode;
            _instantConstructionCheckBox.Checked = false;
            _instantResearchCheckBox.Checked = false;
            _instantTrainingCheckBox.Checked = false;

            SetInput("food", _config.Food);
            SetInput("wood", _config.Wood);
            SetInput("stone", _config.Stone);
            SetInput("iron", _config.Iron);
            SetInput("souls", _config.Souls);
            SetInput("money", _config.Money);

            _summonQuantityInput.Value = 1;
            _summonDurationInput.Value = 300;
            ApplySummonSelectionToUi(new List<int>());
            ApplyTheme();
        }

        private void ToggleTopMost()
        {
            TopMost = !TopMost;
            if (_topMostButton != null)
            {
                _topMostButton.Text = TopMost ? "Top ON" : "Top";
            }

            PlaySwitch(TopMost);
            SetStatus(TopMost ? "Window is topmost." : "Window topmost disabled.");
        }

        private void SetInput(string resource, int value)
        {
            NumericUpDown input;
            if (_inputs.TryGetValue(resource, out input))
            {
                input.Value = Math.Max((int)input.Minimum, Math.Min((int)input.Maximum, value));
            }
        }

        private void HotkeyTimerTick(object sender, EventArgs e)
        {
            if (WasPressed(0, VkNumpadDecimal))
            {
                _enabledCheckBox.Checked = !_enabledCheckBox.Checked;
                PlaySwitch(_enabledCheckBox.Checked);
                SetStatus(_enabledCheckBox.Checked ? "Master switch ON." : "Master switch OFF.");
            }

            if (WasPressed(1, VkNumpad1))
            {
                TrySetResource("wood");
            }

            if (WasPressed(2, VkNumpad2))
            {
                TrySetResource("stone");
            }

            if (WasPressed(3, VkNumpad3))
            {
                TrySetResource("iron");
            }

            if (WasPressed(4, VkNumpad4))
            {
                TrySetResource("food");
            }

            if (WasPressed(5, VkNumpad5))
            {
                TrySetResource("souls");
            }

            if (WasPressed(6, VkNumpad6))
            {
                TrySetResource("money");
            }

            if (WasPressed(7, VkNumpad7))
            {
                ToggleEffect(_instantConstructionCheckBox, "Instant build/upgrade");
            }

            if (WasPressed(8, VkNumpad8))
            {
                ToggleEffect(_instantResearchCheckBox, "Instant research");
            }

            if (WasPressed(9, VkNumpad9))
            {
                ToggleEffect(_instantTrainingCheckBox, "Instant training");
            }

            if (WasPressed(10, VkNumpadDivide))
            {
                ClearSummonOverride();
            }

            if (WasPressed(11, VkNumpadMultiply))
            {
                ToggleSummonOverride();
            }
        }

        private bool WasPressed(int index, int virtualKey)
        {
            bool isDown = (GetAsyncKeyState(virtualKey) & 0x8000) != 0;
            bool pressed = isDown && !_wasDown[index];
            _wasDown[index] = isDown;
            return pressed;
        }

        private void SummonListItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!_isLoadingConfig)
            {
                BeginInvoke((Action)SaveUiToConfig);
            }
        }

        private void ApplyTheme()
        {
            bool dark = _nightModeCheckBox != null && _nightModeCheckBox.Checked;
            Color back = dark ? Color.FromArgb(30, 32, 36) : SystemColors.Control;
            Color fore = dark ? Color.FromArgb(235, 235, 235) : SystemColors.ControlText;
            Color inputBack = dark ? Color.FromArgb(42, 45, 51) : SystemColors.Window;
            Color buttonBack = dark ? Color.FromArgb(54, 58, 66) : SystemColors.Control;

            ApplyThemeToControl(this, back, fore, inputBack, buttonBack, dark);
        }

        private static void ApplyThemeToControl(Control control, Color back, Color fore, Color inputBack, Color buttonBack, bool dark)
        {
            if (control is TextBoxBase || control is ListControl || control is NumericUpDown)
            {
                control.BackColor = inputBack;
                control.ForeColor = fore;
            }
            else if (control is Button)
            {
                control.BackColor = buttonBack;
                control.ForeColor = fore;
            }
            else
            {
                control.BackColor = back;
                control.ForeColor = fore;
            }

            for (int i = 0; i < control.Controls.Count; i++)
            {
                ApplyThemeToControl(control.Controls[i], back, fore, inputBack, buttonBack, dark);
            }
        }

        private void ToggleEffect(CheckBox checkBox, string label)
        {
            if (!_enabledCheckBox.Checked)
            {
                PlayError();
                SetStatus("Master switch is OFF; effect hotkey ignored.");
                return;
            }

            checkBox.Checked = !checkBox.Checked;
            PlaySwitch(checkBox.Checked);
            SetStatus(label + (checkBox.Checked ? " ON." : " OFF."));
        }

        private void TrySetResource(string resource)
        {
            if (!_enabledCheckBox.Checked)
            {
                PlayError();
                SetStatus("Master switch is OFF; resource hotkey ignored.");
                return;
            }

            NumericUpDown input;
            if (!_inputs.TryGetValue(resource, out input))
            {
                PlayError();
                SetStatus("Unknown resource: " + resource);
                return;
            }

            try
            {
                int value = (int)input.Value;
                if (IsWsiResource(resource))
                {
                    QueueResourceCommand(resource, value);
                    PlayConfirm();
                    SetStatus(resource + " queued to " + value + ".");
                    return;
                }

                bool directWritten = TrySetDirectMemoryResource(resource, value);
                QueueResourceCommand(resource, value);
                PlayConfirm();
                SetStatus(resource + (directWritten ? " set to " : " queued to ") + value + ".");
            }
            catch (Exception ex)
            {
                PlayError();
                SetStatus("Failed: " + ex.Message);
            }
        }

        private bool IsWsiResource(string resource)
        {
            return string.Equals(resource, "wood", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(resource, "stone", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(resource, "iron", StringComparison.OrdinalIgnoreCase);
        }

        private void SetDirectMemoryResource(string resource, int value)
        {
            Process process = Program.FindGameProcess();
            AddressMap map = AddressMap.Load(_logPath);
            IntPtr handle = NativeMethods.OpenProcess(
                NativeMethods.ProcessVmRead | NativeMethods.ProcessVmWrite |
                NativeMethods.ProcessVmOperation | NativeMethods.ProcessQueryInformation,
                false,
                process.Id);

            if (handle == IntPtr.Zero)
            {
                throw new InvalidOperationException("OpenProcess failed.");
            }

            try
            {
                if (resource == "food")
                {
                    map.ResolveMainFoodStorage(handle);
                }

                ResourceWriter.SetResource(handle, map, resource, value);
            }
            finally
            {
                NativeMethods.CloseHandle(handle);
            }
        }

        private bool TrySetDirectMemoryResource(string resource, int value)
        {
            try
            {
                SetDirectMemoryResource(resource, value);
                return true;
            }
            catch (Exception ex)
            {
                SetStatus("Direct memory write skipped; helper queued: " + ex.Message);
                return false;
            }
        }

        private void QueueResourceCommand(string resource, int value)
        {
            string directory = Path.GetDirectoryName(_resourceCommandPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string line = DateTime.UtcNow.Ticks + "|" +
                          resource.ToLowerInvariant() + "|" +
                          value + "|" +
                          DateTime.UtcNow.ToString("O") +
                          Environment.NewLine;
            File.AppendAllText(_resourceCommandPath, line);
        }

        private void ToggleSummonOverride()
        {
            if (_summonOverrideActive)
            {
                DisableSummonOverride(false);
                return;
            }

            ApplySummonConfig();
        }

        private void ApplySummonConfig()
        {
            if (!_enabledCheckBox.Checked)
            {
                PlayError();
                SetStatus("Master switch is OFF; summon config ignored.");
                return;
            }

            try
            {
                int quantity = _summonQuantityInput != null ? (int)_summonQuantityInput.Value : 0;
                int durationSeconds = _summonDurationInput != null ? (int)_summonDurationInput.Value : 300;
                List<int> unitIds = GetSelectedSummonUnitIds();
                SaveUiToConfig();
                WriteSummonCommand(quantity, durationSeconds, unitIds);
                _summonOverrideActive = quantity > 0 && unitIds.Count > 0;
                UpdateSummonApplyButtonText();
                PlayConfirm();
                SetStatus("Summon config applied: " + unitIds.Count + " unit type(s), qty " + quantity + ", " + durationSeconds + "s.");
            }
            catch (Exception ex)
            {
                PlayError();
                SetStatus("Summon apply failed: " + ex.Message);
            }
        }

        private void ClearSummonOverride()
        {
            try
            {
                _isLoadingConfig = true;
                try
                {
                    if (_summonQuantityInput != null)
                    {
                        _summonQuantityInput.Value = 1;
                    }

                    ClearSummonListChecks(_friendlySummonList);
                    ClearSummonListChecks(_enemySummonList);
                }
                finally
                {
                    _isLoadingConfig = false;
                }

                SaveUiToConfig();
                DisableSummonOverride(true);
            }
            catch (Exception ex)
            {
                PlayError();
                SetStatus("Summon clear failed: " + ex.Message);
            }
        }

        private void DisableSummonOverride(bool cleared)
        {
            WriteSummonCommand(0, _summonDurationInput != null ? (int)_summonDurationInput.Value : 300, new List<int>());
            _summonOverrideActive = false;
            UpdateSummonApplyButtonText();
            PlaySwitch(false);
            SetStatus(cleared ? "Summon override cleared; default summon restored." : "Summon override OFF; default summon restored.");
        }

        private void UpdateSummonApplyButtonText()
        {
            if (_summonApplyButton != null)
            {
                _summonApplyButton.Text = _summonOverrideActive ? "Numpad* Disable" : "Numpad* Apply";
            }
        }

        private List<int> GetSelectedSummonUnitIds()
        {
            List<int> unitIds = new List<int>();
            AddSelectedSummonUnitIds(unitIds, _friendlySummonList);
            AddSelectedSummonUnitIds(unitIds, _enemySummonList);

            return unitIds;
        }

        private void ApplySummonSelectionToUi(List<int> unitIds)
        {
            if (unitIds == null)
            {
                return;
            }

            HashSet<int> selected = new HashSet<int>(unitIds);
            ApplySummonSelectionToList(_friendlySummonList, selected);
            ApplySummonSelectionToList(_enemySummonList, selected);
        }

        private static void AddSelectedSummonUnitIds(List<int> unitIds, CheckedListBox list)
        {
            if (list == null)
            {
                return;
            }

            for (int i = 0; i < list.CheckedItems.Count; i++)
            {
                SummonUnit unit = list.CheckedItems[i] as SummonUnit;
                if (unit != null)
                {
                    unitIds.Add(unit.Id);
                }
            }
        }

        private static void ApplySummonSelectionToList(CheckedListBox list, HashSet<int> selected)
        {
            if (list == null)
            {
                return;
            }

            for (int i = 0; i < list.Items.Count; i++)
            {
                SummonUnit unit = list.Items[i] as SummonUnit;
                list.SetItemChecked(i, unit != null && selected.Contains(unit.Id));
            }
        }

        private static void ClearSummonListChecks(CheckedListBox list)
        {
            if (list == null)
            {
                return;
            }

            for (int i = 0; i < list.Items.Count; i++)
            {
                list.SetItemChecked(i, false);
            }
        }

        private void ToggleSummonListChecks(CheckedListBox list)
        {
            if (list == null || list.Items.Count == 0)
            {
                return;
            }

            bool allChecked = true;
            for (int i = 0; i < list.Items.Count; i++)
            {
                if (!list.GetItemChecked(i))
                {
                    allChecked = false;
                    break;
                }
            }

            bool nextState = !allChecked;
            for (int i = 0; i < list.Items.Count; i++)
            {
                list.SetItemChecked(i, nextState);
            }

            SaveUiToConfig();
        }

        private void WriteSummonCommand(int quantity, int durationSeconds, List<int> unitIds)
        {
            string directory = Path.GetDirectoryName(_summonCommandPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            bool enabled = quantity > 0 && unitIds.Count > 0;
            string tempPath = _summonCommandPath + ".tmp";
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("id=" + DateTime.UtcNow.Ticks);
            builder.AppendLine("enabled=" + (enabled ? "1" : "0"));
            builder.AppendLine("quantity=" + Math.Max(0, quantity));
            builder.AppendLine("durationSeconds=" + Math.Max(0, durationSeconds));
            builder.AppendLine("units=" + JoinInts(unitIds));
            builder.AppendLine("updatedUtc=" + DateTime.UtcNow.ToString("O"));
            File.WriteAllText(tempPath, builder.ToString());
            if (File.Exists(_summonCommandPath))
            {
                File.Delete(_summonCommandPath);
            }

            File.Move(tempPath, _summonCommandPath);
        }

        private void SaveUiToConfig()
        {
            if (_isLoadingConfig)
            {
                return;
            }

            _config.InstantConstruction = _instantConstructionCheckBox != null && _instantConstructionCheckBox.Checked;
            _config.NightMode = _nightModeCheckBox != null && _nightModeCheckBox.Checked;
            _config.InstantResearch = _instantResearchCheckBox != null && _instantResearchCheckBox.Checked;
            _config.InstantTraining = _instantTrainingCheckBox != null && _instantTrainingCheckBox.Checked;
            _config.Food = GetInputValue("food", _config.Food);
            _config.Wood = GetInputValue("wood", _config.Wood);
            _config.Stone = GetInputValue("stone", _config.Stone);
            _config.Iron = GetInputValue("iron", _config.Iron);
            _config.Souls = GetInputValue("souls", _config.Souls);
            _config.Money = GetInputValue("money", _config.Money);
            if (_summonQuantityInput != null)
            {
                _config.SummonQuantity = (int)_summonQuantityInput.Value;
            }

            if (_summonDurationInput != null)
            {
                _config.SummonDurationSeconds = (int)_summonDurationInput.Value;
            }

            _config.SummonUnitIds = GetSelectedSummonUnitIds();
            _config.Save(_configPath);
        }

        private int GetInputValue(string resource, int fallback)
        {
            NumericUpDown input;
            return _inputs.TryGetValue(resource, out input) ? (int)input.Value : fallback;
        }

        private static string JoinInts(List<int> values)
        {
            if (values == null || values.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < values.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                builder.Append(values[i]);
            }

            return builder.ToString();
        }

        private void WriteStateFile()
        {
            try
            {
                string directory = Path.GetDirectoryName(_statePath);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                StringBuilder builder = new StringBuilder();
                builder.AppendLine("enabled=" + (_enabledCheckBox != null && _enabledCheckBox.Checked ? "1" : "0"));
                builder.AppendLine("instantConstruction=" + (_instantConstructionCheckBox != null && _instantConstructionCheckBox.Checked ? "1" : "0"));
                builder.AppendLine("instantResearch=" + (_instantResearchCheckBox != null && _instantResearchCheckBox.Checked ? "1" : "0"));
                builder.AppendLine("instantTraining=" + (_instantTrainingCheckBox != null && _instantTrainingCheckBox.Checked ? "1" : "0"));
                builder.AppendLine("updatedUtc=" + DateTime.UtcNow.ToString("O"));
                File.WriteAllText(_statePath, builder.ToString());
            }
            catch (Exception ex)
            {
                PlayError();
                SetStatus("State write failed: " + ex.Message);
            }
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            _hotkeyTimer.Stop();
            _enabledCheckBox.Checked = false;
            _instantConstructionCheckBox.Checked = false;
            _instantResearchCheckBox.Checked = false;
            _instantTrainingCheckBox.Checked = false;
            SaveUiToConfig();
            WriteStateFile();
            try
            {
                WriteSummonCommand(0, 300, new List<int>());
            }
            catch
            {
            }
        }

        private void SetStatus(string text)
        {
            if (_statusLabel != null)
            {
                _statusLabel.Text = text;
            }
        }

        private static void PlayStartup()
        {
            SystemSounds.Exclamation.Play();
        }

        private static void PlaySwitch(bool enabled)
        {
            if (enabled)
            {
                SystemSounds.Asterisk.Play();
            }
            else
            {
                SystemSounds.Exclamation.Play();
            }
        }

        private static void PlayConfirm()
        {
            SystemSounds.Beep.Play();
        }

        private static void PlayError()
        {
            SystemSounds.Hand.Play();
        }
    }

    internal sealed class TrainerConfig
    {
        private const int CurrentConfigVersion = 7;

        public int Food = 500;
        public int Wood = 600;
        public int Stone = 600;
        public int Iron = 600;
        public int Souls = 200;
        public int Money = 200;
        public int SummonQuantity = 1;
        public int SummonDurationSeconds = 300;
        public List<int> SummonUnitIds = new List<int>();
        public bool NightMode;
        public bool InstantConstruction;
        public bool InstantResearch;
        public bool InstantTraining;

        public static TrainerConfig Load(string path)
        {
            TrainerConfig config = new TrainerConfig();
            if (!File.Exists(path))
            {
                return config;
            }

            Dictionary<string, string> values = ReadKeyValues(path);
            string versionText;
            int version = 0;
            bool hasVersion =
                values.TryGetValue("configversion", out versionText) &&
                int.TryParse(versionText, out version);
            int configVersion = hasVersion ? version : 0;
            bool hasCurrentVersion = configVersion == CurrentConfigVersion;

            if (configVersion >= 3)
            {
                config.Food = ParseInt(GetValue(values, "food"), config.Food);
                config.Wood = ParseInt(GetValue(values, "wood"), config.Wood);
                config.Stone = ParseInt(GetValue(values, "stone"), config.Stone);
                config.Iron = ParseInt(GetValue(values, "iron"), config.Iron);
                config.Souls = ParseInt(GetValue(values, "souls"), config.Souls);
                config.Money = ParseInt(GetValue(values, "money"), config.Money);
            }

            config.NightMode = ParseBool(GetValue(values, "nightmode"));
            config.InstantConstruction = ParseBool(GetValue(values, "instantconstruction"));
            config.InstantResearch = ParseBool(GetValue(values, "instantresearch"));
            config.InstantTraining = ParseBool(GetValue(values, "instanttraining"));
            config.SummonQuantity = 1;
            config.SummonDurationSeconds = 300;
            config.SummonUnitIds = new List<int>();

            return config;
        }

        public void Save(string path)
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("configVersion=" + CurrentConfigVersion);
            builder.AppendLine("food=" + Food);
            builder.AppendLine("wood=" + Wood);
            builder.AppendLine("stone=" + Stone);
            builder.AppendLine("iron=" + Iron);
            builder.AppendLine("souls=" + Souls);
            builder.AppendLine("money=" + Money);
            builder.AppendLine("summonQuantity=" + SummonQuantity);
            builder.AppendLine("summonDurationSeconds=" + SummonDurationSeconds);
            builder.AppendLine("summonUnits=" + JoinInts(SummonUnitIds));
            builder.AppendLine("nightMode=" + (NightMode ? "1" : "0"));
            builder.AppendLine("instantConstruction=" + (InstantConstruction ? "1" : "0"));
            builder.AppendLine("instantResearch=" + (InstantResearch ? "1" : "0"));
            builder.AppendLine("instantTraining=" + (InstantTraining ? "1" : "0"));
            File.WriteAllText(path, builder.ToString());
        }

        private static Dictionary<string, string> ReadKeyValues(string path)
        {
            Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string[] lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                {
                    continue;
                }

                int separator = line.IndexOf('=');
                if (separator <= 0)
                {
                    continue;
                }

                values[line.Substring(0, separator).Trim()] = line.Substring(separator + 1).Trim();
            }

            return values;
        }

        private static string GetValue(Dictionary<string, string> values, string key)
        {
            string value;
            return values.TryGetValue(key, out value) ? value : null;
        }

        private static int ParseInt(string value, int fallback)
        {
            int parsed;
            return int.TryParse(value, out parsed) ? Math.Max(0, Math.Min(999999, parsed)) : fallback;
        }

        private static bool ParseBool(string value)
        {
            return value == "1" ||
                   string.Equals(value, "true", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(value, "on", StringComparison.OrdinalIgnoreCase);
        }

        private static List<int> ParseIntList(string value)
        {
            List<int> result = new List<int>();
            if (string.IsNullOrEmpty(value))
            {
                return result;
            }

            string[] parts = value.Split(',');
            for (int i = 0; i < parts.Length; i++)
            {
                int parsed;
                if (int.TryParse(parts[i].Trim(), out parsed))
                {
                    result.Add(parsed);
                }
            }

            return result;
        }

        private static string JoinInts(List<int> values)
        {
            if (values == null || values.Count == 0)
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < values.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                builder.Append(values[i]);
            }

            return builder.ToString();
        }
    }

    internal sealed class SummonUnit
    {
        public readonly int Id;
        public readonly string Name;
        public readonly string DisplayName;
        public readonly SummonFaction Faction;
        public readonly bool IsSelfSummoner;

        public SummonUnit(int id, string name)
            : this(id, name, null, SummonUnitCatalog.InferFaction(id, name, null))
        {
        }

        public SummonUnit(int id, string name, string displayName)
            : this(id, name, displayName, SummonUnitCatalog.InferFaction(id, name, displayName))
        {
        }

        public SummonUnit(int id, string name, string displayName, SummonFaction faction)
        {
            Id = id;
            Name = name;
            DisplayName = string.IsNullOrWhiteSpace(displayName) ? null : displayName.Trim();
            Faction = faction;
            IsSelfSummoner = SummonUnitCatalog.IsSelfSummonerId(id);
        }

        public override string ToString()
        {
            string prefix = "[" + Id + "] ";
            string warning = IsSelfSummoner ? "[\u2666\u2666\u2666] " : string.Empty;
            string suffix = IsSelfSummoner ? " [\u81EA\u53EC\u5524]" : string.Empty;
            if (string.IsNullOrEmpty(DisplayName) ||
                string.Equals(DisplayName, Name, StringComparison.OrdinalIgnoreCase))
            {
                return prefix + warning + Name + suffix;
            }

            return prefix + warning + Name + " / " + DisplayName + suffix;
        }
    }

    internal enum SummonFaction
    {
        Player = 0,
        Enemy = 1
    }

    internal static class SummonUnitCatalog
    {
        private static readonly CompareInfo ZhCompare = CultureInfo.GetCultureInfo("zh-CN").CompareInfo;

        public static SummonUnit[] LoadByFaction(string catalogPath, string reviewPath, SummonFaction faction)
        {
            SummonUnit[] units = Load(catalogPath, reviewPath);
            Array.Sort(units, CompareUnits);

            List<SummonUnit> result = new List<SummonUnit>();
            for (int i = 0; i < units.Length; i++)
            {
                if (units[i].Faction == faction)
                {
                    result.Add(units[i]);
                }
            }

            return result.ToArray();
        }

        public static SummonUnit[] Load(string catalogPath, string reviewPath)
        {
            Dictionary<int, string> displayNames = LoadDisplayNames(catalogPath);
            Dictionary<int, SummonFaction> factionOverrides = LoadFactionOverrides(reviewPath);
            SummonUnit[] result = new SummonUnit[Units.Length];
            for (int i = 0; i < Units.Length; i++)
            {
                SummonUnit unit = Units[i];
                string displayName;
                displayNames.TryGetValue(unit.Id, out displayName);
                SummonFaction faction;
                if (!factionOverrides.TryGetValue(unit.Id, out faction))
                {
                    faction = InferFaction(unit.Id, unit.Name, displayName);
                }

                result[i] = new SummonUnit(unit.Id, unit.Name, displayName, faction);
            }

            return result;
        }

        public static SummonFaction InferFaction(int id, string name, string displayName)
        {
            string display = displayName ?? string.Empty;

            if (string.Equals(name, "NativesPlayerHealer", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(name, "PlayerUndeadKamikaze", StringComparison.OrdinalIgnoreCase) ||
                EqualsAny(name, "Shanhar", "ShanharOnGiant", "Snut"))
            {
                return SummonFaction.Player;
            }

            if (StartsWithAny(display, "萨兰加", "萨加兰") ||
                ContainsAny(display, "叛军", "座狼") ||
                EqualsAny(name, "Dragon", "Rabbit", "BannerPeasant", "Scott"))
            {
                return SummonFaction.Enemy;
            }

            if (StartsWithAny(name, "Royal", "Undead", "Harpy", "Demon", "Lich", "WaterCreature", "Wolf") ||
                StartsWithAny(name, "Natives") ||
                EqualsAny(name, "Cadaver", "CadaverHorse", "DarkKnight", "Giant", "GiantBig", "GiantFather", "King", "Pinata", "SarrangaCheif"))
            {
                return SummonFaction.Enemy;
            }

            return SummonFaction.Player;
        }

        private static int CompareUnits(SummonUnit left, SummonUnit right)
        {
            int selfSummonerCompare = left.IsSelfSummoner.CompareTo(right.IsSelfSummoner);
            if (selfSummonerCompare != 0)
            {
                return selfSummonerCompare;
            }

            return left.Id.CompareTo(right.Id);
        }

        private static string GetSortText(SummonUnit unit)
        {
            string text = string.IsNullOrEmpty(unit.DisplayName) ? unit.Name : unit.DisplayName;
            return GetSortFamilyRank(unit.Name, unit.DisplayName).ToString("00") + " " +
                   GetSortFamily(unit.Name, unit.DisplayName) + " " +
                   text + " " + unit.Name;
        }

        public static string GetReviewSortFamily(SummonUnit unit)
        {
            return GetSortFamily(unit.Name, unit.DisplayName);
        }

        public static bool IsSelfSummonerId(int id)
        {
            return id == 56 || id == 70 || id == 87;
        }

        private static string GetSortFamily(string name, string displayName)
        {
            string display = displayName ?? string.Empty;
            if (StartsWithAny(display, "萨兰加", "萨加兰"))
            {
                return "萨兰加";
            }

            if (display.IndexOf("叛军", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "叛军";
            }

            if (display.IndexOf("座狼", StringComparison.OrdinalIgnoreCase) >= 0 ||
                StartsWithAny(name, "Wolf"))
            {
                return "座狼";
            }

            if (StartsWithAny(display, "皇家") || StartsWithAny(name, "Royal"))
            {
                return "皇家";
            }

            return string.IsNullOrEmpty(display) ? name : display;
        }

        private static int GetSortFamilyRank(string name, string displayName)
        {
            string display = displayName ?? string.Empty;
            if (StartsWithAny(display, "皇家") || StartsWithAny(name, "Royal"))
            {
                return 10;
            }

            if (StartsWithAny(display, "萨兰加", "萨加兰") ||
                StartsWithAny(name, "Natives") ||
                EqualsAny(name, "Pinata", "SarrangaCheif"))
            {
                return 20;
            }

            if (display.IndexOf("叛军", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return 30;
            }

            if (display.IndexOf("座狼", StringComparison.OrdinalIgnoreCase) >= 0 ||
                StartsWithAny(name, "Wolf"))
            {
                return 40;
            }

            if (StartsWithAny(name, "Undead", "Lich", "Demon") ||
                ContainsAny(display, "亡灵", "死灵", "黑暗", "梦魇", "食尸鬼", "不应存在"))
            {
                return 50;
            }

            if (StartsWithAny(name, "Harpy", "WaterCreature") ||
                EqualsAny(name, "Dragon", "Rabbit", "Giant", "GiantBig", "GiantFather"))
            {
                return 60;
            }

            return 90;
        }

        private static bool StartsWithAny(string value, params string[] prefixes)
        {
            if (string.IsNullOrEmpty(value))
            {
                return false;
            }

            for (int i = 0; i < prefixes.Length; i++)
            {
                if (value.StartsWith(prefixes[i], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool ContainsAny(string value, params string[] parts)
        {
            if (string.IsNullOrEmpty(value))
            {
                return false;
            }

            for (int i = 0; i < parts.Length; i++)
            {
                if (value.IndexOf(parts[i], StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static bool EqualsAny(string value, params string[] names)
        {
            for (int i = 0; i < names.Length; i++)
            {
                if (string.Equals(value, names[i], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static Dictionary<int, string> LoadDisplayNames(string catalogPath)
        {
            Dictionary<int, string> displayNames = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(catalogPath) || !File.Exists(catalogPath))
            {
                return displayNames;
            }

            try
            {
                string[] lines = File.ReadAllLines(catalogPath);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                    {
                        continue;
                    }

                    string[] parts = line.Split('|');
                    if (parts.Length < 3)
                    {
                        continue;
                    }

                    int id;
                    if (!int.TryParse(parts[0].Trim(), out id))
                    {
                        continue;
                    }

                    string displayName = parts[2].Trim();
                    if (displayName.Length > 0)
                    {
                        displayNames[id] = displayName;
                    }
                }
            }
            catch
            {
            }

            return displayNames;
        }

        private static Dictionary<int, SummonFaction> LoadFactionOverrides(string reviewPath)
        {
            Dictionary<int, SummonFaction> overrides = new Dictionary<int, SummonFaction>();
            if (string.IsNullOrEmpty(reviewPath) || !File.Exists(reviewPath))
            {
                return overrides;
            }

            try
            {
                string[] lines = File.ReadAllLines(reviewPath, Encoding.UTF8);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal) || line.StartsWith("---", StringComparison.Ordinal))
                    {
                        continue;
                    }

                    string[] parts = line.Split('|');
                    if (parts.Length < 2)
                    {
                        continue;
                    }

                    SummonFaction faction;
                    string factionText = parts[0].Trim();
                    if (string.Equals(factionText, "\u53CB\u65B9", StringComparison.OrdinalIgnoreCase))
                    {
                        faction = SummonFaction.Player;
                    }
                    else if (string.Equals(factionText, "\u654C\u65B9", StringComparison.OrdinalIgnoreCase))
                    {
                        faction = SummonFaction.Enemy;
                    }
                    else
                    {
                        continue;
                    }

                    int id;
                    if (!int.TryParse(parts[1].Trim(), out id))
                    {
                        continue;
                    }

                    overrides[id] = faction;
                }
            }
            catch
            {
            }

            return overrides;
        }

        private static readonly SummonUnit[] Units = new SummonUnit[]
        {
            new SummonUnit(1, "Archer"),
            new SummonUnit(2, "Swordsman"),
            new SummonUnit(3, "Ballista"),
            new SummonUnit(4, "BannerPeasant"),
            new SummonUnit(5, "Trebuchet"),
            new SummonUnit(6, "Catapult"),
            new SummonUnit(7, "Doctor"),
            new SummonUnit(8, "Horseman"),
            new SummonUnit(9, "Crossbowman"),
            new SummonUnit(10, "Hammerman"),
            new SummonUnit(11, "Spearman"),
            new SummonUnit(12, "ShieldPeasant"),
            new SummonUnit(13, "ForkPeasant"),
            new SummonUnit(14, "BigPeasant"),
            new SummonUnit(15, "Scott"),
            new SummonUnit(16, "Cadaver"),
            new SummonUnit(17, "PeasantCatapult"),
            new SummonUnit(18, "DarkKnight"),
            new SummonUnit(19, "ScythePeasant"),
            new SummonUnit(20, "RoyalSwordsman"),
            new SummonUnit(21, "RoyalSpearHorseman"),
            new SummonUnit(22, "RoyalSwordHorseman"),
            new SummonUnit(23, "RoyalBigSwordsMan"),
            new SummonUnit(24, "RoyalCatapult"),
            new SummonUnit(25, "RoyalRam"),
            new SummonUnit(26, "RoyalBanner"),
            new SummonUnit(27, "RoyalSpearman"),
            new SummonUnit(28, "Brander"),
            new SummonUnit(29, "Cavalier"),
            new SummonUnit(30, "Knight"),
            new SummonUnit(31, "AxeWarrior"),
            new SummonUnit(32, "MountedArcher"),
            new SummonUnit(33, "CadaverHorse"),
            new SummonUnit(34, "UndeadArmored"),
            new SummonUnit(35, "UndeadCatapult"),
            new SummonUnit(36, "UndeadGhost"),
            new SummonUnit(37, "UndeadKamikaze"),
            new SummonUnit(38, "UndeadRabid"),
            new SummonUnit(39, "UndeadZerg"),
            new SummonUnit(40, "NativesHealer"),
            new SummonUnit(41, "SummonedRange"),
            new SummonUnit(42, "SummonedMelee"),
            new SummonUnit(43, "NativesArcher"),
            new SummonUnit(44, "NativesBomber"),
            new SummonUnit(45, "NativesChest"),
            new SummonUnit(46, "NativesCrusher"),
            new SummonUnit(47, "NativesKnight"),
            new SummonUnit(48, "NativesRogue"),
            new SummonUnit(49, "NativesScorpion"),
            new SummonUnit(50, "UndeadChest"),
            new SummonUnit(51, "Lord"),
            new SummonUnit(52, "Snut"),
            new SummonUnit(53, "Shanhar"),
            new SummonUnit(54, "LichNecro"),
            new SummonUnit(55, "LichSummon"),
            new SummonUnit(56, "DemonBoss"),
            new SummonUnit(57, "RoyalBallista"),
            new SummonUnit(58, "RoyalTrebuchet"),
            new SummonUnit(59, "RoyalTrebuchetLight"),
            new SummonUnit(60, "RoyalDestructionMachine"),
            new SummonUnit(61, "RoyalCrossbowman"),
            new SummonUnit(62, "RoyalShortswordsman"),
            new SummonUnit(63, "RoyalArcher"),
            new SummonUnit(64, "RoyalHulk"),
            new SummonUnit(65, "WaterCreature"),
            new SummonUnit(66, "Giant"),
            new SummonUnit(67, "GiantBig"),
            new SummonUnit(68, "HarpyAcid"),
            new SummonUnit(69, "HarpyBig"),
            new SummonUnit(70, "HarpyBoss"),
            new SummonUnit(71, "HarpyRegular"),
            new SummonUnit(72, "HarpyTiny"),
            new SummonUnit(73, "HarpyFast"),
            new SummonUnit(74, "NativesPlayerHealer"),
            new SummonUnit(76, "WaterCreatureRegular"),
            new SummonUnit(77, "WaterCreatureSmall"),
            new SummonUnit(78, "WaterCreatureStrong"),
            new SummonUnit(79, "King"),
            new SummonUnit(80, "Dragon"),
            new SummonUnit(81, "Pinata"),
            new SummonUnit(82, "ShanharOnGiant"),
            new SummonUnit(83, "Wolf"),
            new SummonUnit(84, "WolfAgile"),
            new SummonUnit(85, "WolfWeak"),
            new SummonUnit(86, "WolfMagic"),
            new SummonUnit(87, "GiantFather"),
            new SummonUnit(88, "PlayerUndeadKamikaze"),
            new SummonUnit(89, "Rabbit"),
            new SummonUnit(90, "SarrangaCheif")
        };
    }

    internal static class ResourceWriter
    {
        public static void SetResource(IntPtr handle, AddressMap map, string resource, int value)
        {
            switch (resource.ToLowerInvariant())
            {
                case "wood":
                    EnsurePlausible(handle, map.CurrentWood, "wood current");
                    WriteInt32(handle, map.CurrentWood, value);
                    break;
                case "stone":
                    EnsurePlausible(handle, map.CurrentStone, "stone current");
                    WriteInt32(handle, map.CurrentStone, value);
                    break;
                case "iron":
                    EnsurePlausible(handle, map.CurrentIron, "iron current");
                    WriteInt32(handle, map.CurrentIron, value);
                    break;
                case "food":
                    EnsurePlausible(handle, map.CurrentFood, "food currentValueField");
                    EnsurePlausible(handle, map.GetCurrentFoodComponentOrFallback(), "food component");
                    if (map.MainFoodStorage != 0)
                    {
                        EnsurePlausible(handle, map.MainFoodStorage, "food storage");
                    }

                    WriteCurrentPair(handle, map.GetCurrentFoodComponentOrFallback(), map.CurrentFood, value);
                    if (map.MainFoodStorage != 0)
                    {
                        WriteInt32(handle, map.MainFoodStorage, value);
                    }
                    break;
                case "souls":
                    EnsurePlausible(handle, map.CurrentSouls, "souls currentValueField");
                    EnsurePlausible(handle, map.GetCurrentSoulsComponentOrFallback(), "souls component");
                    WriteCurrentPair(handle, map.GetCurrentSoulsComponentOrFallback(), map.CurrentSouls, value);
                    break;
                case "money":
                    EnsurePlausible(handle, map.CurrentMoney, "money currentValueField");
                    EnsurePlausible(handle, map.GetCurrentMoneyComponentOrFallback(), "money component");
                    WriteCurrentPair(handle, map.GetCurrentMoneyComponentOrFallback(), map.CurrentMoney, value);
                    break;
                default:
                    throw new InvalidOperationException("Unknown resource: " + resource);
            }
        }

        private static int ReadInt32(IntPtr handle, long address)
        {
            if (address == 0)
            {
                throw new InvalidOperationException("Missing address.");
            }

            byte[] buffer = new byte[4];
            IntPtr bytesRead;
            if (!NativeMethods.ReadProcessMemory(handle, new IntPtr(address), buffer, buffer.Length, out bytesRead) ||
                bytesRead.ToInt64() != 4)
            {
                throw new InvalidOperationException("Read failed at 0x" + address.ToString("X") + ".");
            }

            return BitConverter.ToInt32(buffer, 0);
        }

        private static void WriteInt32(IntPtr handle, long address, int value)
        {
            if (address == 0)
            {
                throw new InvalidOperationException("Missing address.");
            }

            byte[] buffer = BitConverter.GetBytes(value);
            IntPtr bytesWritten;
            if (!NativeMethods.WriteProcessMemory(handle, new IntPtr(address), buffer, buffer.Length, out bytesWritten) ||
                bytesWritten.ToInt64() != 4)
            {
                throw new InvalidOperationException("Write failed at 0x" + address.ToString("X") + ".");
            }
        }

        private static void WriteCurrentPair(IntPtr handle, long componentAddress, long valueFieldAddress, int value)
        {
            WriteInt32(handle, componentAddress, value);
            WriteInt32(handle, valueFieldAddress, value);
        }

        private static void EnsurePlausible(IntPtr handle, long address, string label)
        {
            if (address == 0)
            {
                throw new InvalidOperationException(
                    label + " address is missing. Enter a game and wait a few seconds for the helper address logger.");
            }

            int value = ReadInt32(handle, address);
            if (value < -10000 || value > 5000000)
            {
                throw new InvalidOperationException(
                    label + " address looks stale or unsafe: 0x" + address.ToString("X") +
                    " currently reads " + value + ". Trigger one in-game resource change so the logger refreshes.");
            }
        }
    }

    internal sealed class AddressMap
    {
        private static readonly Regex CurrentRegex = new Regex(
            @"Current(?<name>Wood|Stone|Iron|Food|Souls|Money)\[\d+\].*?(?:component=(?<component>0x[0-9a-fA-F]+).*?)?currentValueField=(?<addr>0x[0-9a-fA-F]+)",
            RegexOptions.Compiled);

        private static readonly Regex StorageRegex = new Regex(
            @"(?<name>Wood|Stone|Iron|Food)Storage\[\d+\] entity=(?<entity>\S+) addr=(?<addr>0x[0-9a-fA-F]+) stored=(?<stored>-?\d+)",
            RegexOptions.Compiled);

        private readonly Dictionary<string, Dictionary<string, StorageEntry>> _storages =
            new Dictionary<string, Dictionary<string, StorageEntry>>(StringComparer.OrdinalIgnoreCase);

        public long CurrentWood;
        public long CurrentStone;
        public long CurrentIron;
        public long CurrentFoodComponent;
        public long CurrentFood;
        public long CurrentSoulsComponent;
        public long CurrentSouls;
        public long CurrentMoneyComponent;
        public long CurrentMoney;
        public long MainFoodStorage;

        public static AddressMap Load(string logPath)
        {
            if (!File.Exists(logPath))
            {
                throw new FileNotFoundException("Log file not found.", logPath);
            }

            AddressMap map = new AddressMap();
            string[] lines;
            using (FileStream stream = new FileStream(logPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (StreamReader reader = new StreamReader(stream))
            {
                lines = reader.ReadToEnd().Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            }

            for (int i = 0; i < lines.Length; i++)
            {
                Match currentMatch = CurrentRegex.Match(lines[i]);
                if (currentMatch.Success)
                {
                    string name = currentMatch.Groups["name"].Value.ToLowerInvariant();
                    long address = ParseHex(currentMatch.Groups["addr"].Value);
                    long componentAddress = currentMatch.Groups["component"].Success
                        ? ParseHex(currentMatch.Groups["component"].Value)
                        : 0;
                    map.SetCurrent(name, componentAddress, address);
                    continue;
                }

                Match storageMatch = StorageRegex.Match(lines[i]);
                if (storageMatch.Success)
                {
                    string name = storageMatch.Groups["name"].Value.ToLowerInvariant();
                    string entity = storageMatch.Groups["entity"].Value;
                    long address = ParseHex(storageMatch.Groups["addr"].Value);
                    int stored = int.Parse(storageMatch.Groups["stored"].Value);
                    map.AddStorage(name, entity, address, stored);
                }
            }

            return map;
        }

        public void ResolveMainFoodStorage(IntPtr handle)
        {
            int currentFood = ReadInt32(handle, CurrentFood);
            long bestAddress = 0;
            int bestScore = int.MinValue;

            foreach (KeyValuePair<string, Dictionary<string, StorageEntry>> pair in _storages)
            {
                StorageEntry entry;
                if (!pair.Value.TryGetValue("food", out entry))
                {
                    continue;
                }

                int stored = ReadInt32(handle, entry.Address);
                if (stored < -10000 || stored > 5000000)
                {
                    continue;
                }

                int score = stored == currentFood ? 100000 : -Math.Min(10000, Math.Abs(stored - currentFood));
                if (score > bestScore)
                {
                    bestScore = score;
                    bestAddress = entry.Address;
                }
            }

            MainFoodStorage = bestAddress;
        }

        public long GetCurrentFoodComponentOrFallback()
        {
            return CurrentFoodComponent != 0 ? CurrentFoodComponent : (CurrentFood != 0 ? CurrentFood - 4 : 0);
        }

        public long GetCurrentSoulsComponentOrFallback()
        {
            return CurrentSoulsComponent != 0 ? CurrentSoulsComponent : (CurrentSouls != 0 ? CurrentSouls - 4 : 0);
        }

        public long GetCurrentMoneyComponentOrFallback()
        {
            return CurrentMoneyComponent != 0 ? CurrentMoneyComponent : (CurrentMoney != 0 ? CurrentMoney - 4 : 0);
        }

        private void SetCurrent(string name, long componentAddress, long valueFieldAddress)
        {
            switch (name)
            {
                case "wood":
                    CurrentWood = valueFieldAddress;
                    break;
                case "stone":
                    CurrentStone = valueFieldAddress;
                    break;
                case "iron":
                    CurrentIron = valueFieldAddress;
                    break;
                case "food":
                    CurrentFoodComponent = componentAddress;
                    CurrentFood = valueFieldAddress;
                    break;
                case "souls":
                    CurrentSoulsComponent = componentAddress;
                    CurrentSouls = valueFieldAddress;
                    break;
                case "money":
                    CurrentMoneyComponent = componentAddress;
                    CurrentMoney = valueFieldAddress;
                    break;
            }
        }

        private void AddStorage(string name, string entity, long address, int stored)
        {
            Dictionary<string, StorageEntry> byResource;
            if (!_storages.TryGetValue(entity, out byResource))
            {
                byResource = new Dictionary<string, StorageEntry>(StringComparer.OrdinalIgnoreCase);
                _storages[entity] = byResource;
            }

            byResource[name] = new StorageEntry(address, stored);
        }

        private void ValidateCurrents()
        {
            if (CurrentWood == 0 || CurrentStone == 0 || CurrentIron == 0 ||
                CurrentFood == 0 || CurrentSouls == 0 || CurrentMoney == 0)
            {
                throw new InvalidOperationException("Resource addresses are incomplete. Enter a game and trigger one resource change first.");
            }
        }

        private static int ReadInt32(IntPtr handle, long address)
        {
            if (address == 0)
            {
                throw new InvalidOperationException("Missing address.");
            }

            byte[] buffer = new byte[4];
            IntPtr bytesRead;
            if (!NativeMethods.ReadProcessMemory(handle, new IntPtr(address), buffer, buffer.Length, out bytesRead) ||
                bytesRead.ToInt64() != 4)
            {
                throw new InvalidOperationException("Read failed at 0x" + address.ToString("X") + ".");
            }

            return BitConverter.ToInt32(buffer, 0);
        }

        private static long ParseHex(string value)
        {
            return Convert.ToInt64(value.Substring(2), 16);
        }

        private sealed class StorageEntry
        {
            public readonly long Address;
            public readonly int Stored;

            public StorageEntry(long address, int stored)
            {
                Address = address;
                Stored = stored;
            }
        }
    }

    internal static class NativeMethods
    {
        public const int ProcessVmRead = 0x0010;
        public const int ProcessVmWrite = 0x0020;
        public const int ProcessVmOperation = 0x0008;
        public const int ProcessQueryInformation = 0x0400;

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr OpenProcess(int access, bool inheritHandle, int processId);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool ReadProcessMemory(IntPtr process, IntPtr address, byte[] buffer, int size, out IntPtr bytesRead);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool WriteProcessMemory(IntPtr process, IntPtr address, byte[] buffer, int size, out IntPtr bytesWritten);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool CloseHandle(IntPtr handle);
    }
}
