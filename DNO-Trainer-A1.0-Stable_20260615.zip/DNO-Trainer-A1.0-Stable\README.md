# DNO Trainer A1.0 Stable

`DNO Trainer A1.0 Stable` 是《Diplomacy is Not an Option》的单机修改器实验版，包含一个外部 WinForms 修改器和一个 BepInEx helper 插件。

本版本基于项目内部 `A1.0 Stable / V032` 逻辑封版，目标是提供稳定的资源修改、即时完成、基础召唤和单位穿插功能。后续 V033 之后的敌对单位控制、属性复原等实验功能没有合入本发布包。

## 免责声明

- 仅建议用于单机、离线、个人学习和自用测试。
- 使用前请确认没有违反游戏 EULA/TOS。
- 本项目与游戏官方无关。
- 游戏更新后，内存地址、ECS 组件或 BepInEx 加载方式可能变化，导致功能失效。
- 修改器会向游戏进程写入内存并加载 BepInEx 插件，杀毒软件或 SmartScreen 可能提示未知程序。

## 文件说明

```text
DNO-Trainer-A1.0-Stable/
  DinaoExternalTrainer.exe          外部修改器主程序
  DinaoExternalTrainer.config.txt   修改器默认配置
  DinaoStorageAutoMarker.dll        BepInEx helper 插件
  install_version.ps1               安装 helper 到游戏 BepInEx\plugins
  disable_helper.ps1                禁用游戏目录中的 helper
  中英对照表_ID排序输出.txt           召唤单位 ID / 英文名 / 中文名 / 阵营对照
  docs/
    版本说明.txt
    A1.0测试结论.txt
    迭代日志_A1.0.txt
    hashes_original.txt
  source/
    DinaoExternalTrainer.cs
    DinaoStorageAutoMarkerPlugin.cs
```

## 前置条件

- Windows。
- 游戏本体已安装。
- 游戏目录中已安装 BepInEx 5.x。
- 默认脚本假设游戏目录为：

```powershell
X:\GAME\Diplomacy is Not an Option
```

如果你的游戏目录不同，请在运行安装脚本时传入 `-GameDir`。

## 安装

1. 完全退出游戏进程。
2. 解压本发布包。
3. 在 PowerShell 中进入解压后的目录。
4. 运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install_version.ps1
```

如果游戏不在默认路径，使用：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install_version.ps1 -GameDir "你的游戏目录"
```

5. 启动游戏。
6. 启动 `DinaoExternalTrainer.exe`。

安装成功后，BepInEx 日志中应出现类似：

```text
DINAO Helper A1.0 Stable / plugin 1.0.0 loaded
```

BepInEx 日志通常位于：

```text
<游戏目录>\BepInEx\LogOutput.log
```

## 卸载 / 禁用 helper

完全退出游戏后，在发布包目录运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\disable_helper.ps1
```

如果游戏不在默认路径：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\disable_helper.ps1 -GameDir "你的游戏目录"
```

## 基本使用

1. 先启动游戏并进入局内。
2. 启动 `DinaoExternalTrainer.exe`。
3. 勾选或按小键盘 `.` 打开总开关。
4. 使用小键盘热键或窗口按钮修改资源、开关即时功能、应用召唤配置。

窗口标题应显示：

```text
DINAO External Trainer A1.0 Stable
```

## 热键

所有热键均为小键盘。

| 热键 | 功能 |
| --- | --- |
| `Numpad .` | 总开关 |
| `Numpad 1` | 设置木材 |
| `Numpad 2` | 设置石材 |
| `Numpad 3` | 设置铁 |
| `Numpad 4` | 设置食物 |
| `Numpad 5` | 设置灵魂水晶 |
| `Numpad 6` | 设置金币 |
| `Numpad 7` | 建造 / 升级立即完成开关 |
| `Numpad 8` | 研究立即完成开关 |
| `Numpad 9` | 训练立即完成开关 |
| `Numpad /` | 清除召唤修改 |
| `Numpad *` | 应用 / 取消召唤修改 |

## 已验证功能

A1.0 Stable 测试结论：

- 资源修改：木材、石材、铁、食物、灵魂水晶、金币可用。
- 资源 UI 即时刷新：当前版本视为稳定。
- 建造 / 升级立即完成：可用。
- 研究立即完成：可用。
- 训练立即完成：可用。
- 召唤：数量、持续时间、永久召唤、应用 / 清除热键可用。
- 召唤时间条显示：当前版本视为稳定。
- `duration=0`：所有单位已测试不崩溃。
- 召唤列表：自召唤单位标记为 `[♦♦♦]` 并置底。

## 已知限制

以下项目没有作为 A1.0 Stable 的验收目标：

- 敌对召唤单位的点地移动、巡逻、移动攻击。
- 敌对大型单位的子召唤物阵营 / 内战问题。
- 敌对单位血条颜色。
- 后续 V033+ 实验线中的敌对单位属性复原、proxy 控制、特殊单位技能桥等功能。

如果你需要继续开发这些内容，请不要基于发布包盲改；应回到完整开发工作区和版本快照。

## 校验

发布包内包含：

```text
docs\hashes_original.txt
```

也可以自行计算：

```powershell
Get-FileHash .\DinaoExternalTrainer.exe -Algorithm SHA256
Get-FileHash .\DinaoStorageAutoMarker.dll -Algorithm SHA256
```

A1.0 Stable 关键文件原始 SHA256：

```text
DinaoExternalTrainer.exe
F2304BDAC6C5463C3306024DC4DF7C9F8EED6D1C4D1E5694CE72BB39EC71C44D

DinaoStorageAutoMarker.dll
4E46FE145E9338F428FF4BC25956AB564252E001603F97C1919E16A28910D9FC
```

## 给开发者

源码随包放在 `source/` 目录：

- `source/DinaoExternalTrainer.cs`
- `source/DinaoStorageAutoMarkerPlugin.cs`

本发布包是稳定封版包，不包含完整历史版本快照。如果要继续开发，请在完整工作区中阅读：

```text
工作区指引_GPT新对话必读.txt
build\versions\V060_20260615_081925_normal_proxy_no_entity_stats\README_新对话先读这里.txt
```

