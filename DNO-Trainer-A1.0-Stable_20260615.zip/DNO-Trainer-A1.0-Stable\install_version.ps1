﻿param(
    [string]$GameDir = 'X:\GAME\Diplomacy is Not an Option'
)

$ErrorActionPreference = 'Stop'
$VersionDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDll = Join-Path $VersionDir 'DinaoStorageAutoMarker.dll'
$PluginDir = Join-Path $GameDir 'BepInEx\plugins'
$TargetDll = Join-Path $PluginDir 'DinaoStorageAutoMarker.dll'

if (-not (Test-Path -LiteralPath $SourceDll)) {
    throw "Version helper DLL not found: $SourceDll"
}

New-Item -ItemType Directory -Path $PluginDir -Force | Out-Null
if (Test-Path -LiteralPath $TargetDll) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    Copy-Item -LiteralPath $TargetDll -Destination ($TargetDll + ".backup_$stamp") -Force
}

Copy-Item -LiteralPath $SourceDll -Destination $TargetDll -Force
Write-Host "Installed helper from: $VersionDir"
Write-Host "To: $TargetDll"
Get-FileHash -LiteralPath $SourceDll -Algorithm SHA256
Get-FileHash -LiteralPath $TargetDll -Algorithm SHA256
