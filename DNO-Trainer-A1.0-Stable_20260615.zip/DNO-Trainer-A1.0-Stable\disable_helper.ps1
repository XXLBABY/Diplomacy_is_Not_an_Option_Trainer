﻿param(
    [string]$GameDir = 'X:\GAME\Diplomacy is Not an Option'
)

$ErrorActionPreference = 'Stop'
$TargetDll = Join-Path $GameDir 'BepInEx\plugins\DinaoStorageAutoMarker.dll'
if (-not (Test-Path -LiteralPath $TargetDll)) {
    Write-Host "Helper is already absent: $TargetDll"
    return
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$DisabledPath = $TargetDll + ".disabled_$stamp"
Move-Item -LiteralPath $TargetDll -Destination $DisabledPath -Force
Write-Host "Disabled helper: $DisabledPath"
